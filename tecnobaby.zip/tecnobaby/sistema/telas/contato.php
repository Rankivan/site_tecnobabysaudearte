
  





  <div id="back_ground_pagina_contatos">

				    <!--<img src="">-->
				<div>

                    <div>
				  	<h5><img src="../../imagens/comentarios.png" id="img_comentarios" >
                    
				  	<div id="msg_1"> Dúvidas, Elogios e sugestões. Contate-nos</div></h5>
                    
				  	<br></div>


                   <div>
				    <h5><img src="../../imagens/contato.png" id="img_telefone"> 
				    
				    <div id="posicao_telefone">
				    <div id="tel_1">Telefone: (61) 99262-0397</div>
				    <div id="email_1"> tecnobabysaudeearte@gmail.com </div>
				    </div><br>
				   

				    </h5></div>

				   

				</div>
  	
				<div id="formulario_contato">

					

                      <div class="form-group">

                      	<label for="exampleInputEmail1"> Nome Completo </label>
					    <input type="" id="nome" class="form-control"  >


                      </div>


					  <div class="form-group">

					    <label for="exampleInputEmail1">E-mail </label>
					    <input type="email" id="email" class="form-control"  aria-describedby="emailHelp">
					
					  </div>

					  <div class="form-group">

					    <label for="exampleInputEmail1">Seu texto: </label>

					    <textarea id="mensagem" class="form-control" ></textarea>

					  </div>

					  <div class="form-group form-check">
					  </div>

                     <div id="botao_enviar_form">
					  <button id="botao_enviar_form_2" onclick="enviar_formulario();" class="btn btn-primary">Enviar</button>
                     </div>

					

				</div>


				<h5><output  style="color: #146d09" id="mensagem_contato"></output></h5>

			   

			






				

				<div id="texto_final_form">

				<div id="texto_final_form_2"><h5>Este é o nosso link do Whatsapp, clique e fale conosco!</h5>

				<h6> Nós respondemos em dias uteis de <u>segunda a sábado dás 8 às 19 horas </h6>	

				</div>
			  	<div id="zapzap_img"><a href="http://api.whatsapp.com/send?phone=5561992620397"><img src="../../imagens/zapzap.png" id="zapzap"style="padding: 15px"></a></div>
			  	
                </div>
					


  </div>




  <script type="text/javascript" src="../javascript/kontato_ajax.js"></script>

  

  

