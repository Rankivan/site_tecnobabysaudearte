    

		 <?php 
		 session_start();

         //ATR_COMPRAS

		      	$slide_pct_p = 'atr_compras/slide_pact_p.php';
            $slide_pct_m = 'atr_compras/slide_pact_m.php';
            $slide_pct_g = 'atr_compras/slide_pact_g.php';
            $slide_pct_kit = 'atr_compras/slide_pact_kit.php';




		      	$produtos = 'atr_compras/produtos_compras.php';
            $ver_mais = 'atr_compras/modal_ver_mais.php';
            $carrinho_de_compras = 'atr_compras/carrinho_de_compras.php';

		  ?>

    	


    <div class="row">


    	<img src="../../imagens/entrega_compras.png" id="compras_img">


    </div > 



<div>
    <button id="botao_frete" type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal"> <h6>  <img src="../../imagens/caminhao.png" id="img_btn_caminhao">  Calcular o meu envio</h6>
    	
    </button> 
</div><br>

    <div id="div_botao_carrinho">
    	<button id="botao_carrinho" type="button" class=" btn btn-secondary"  data-toggle="modal" data-target="#incluir_pct_p" onclick="calculador();enviar();"> <img src="../../imagens/carrinho_de_compras.png"id="img_btn_carrinho">
    		Meu carrinho de compras
    	</button>
    	
    </div>

<div id="margin_card">
    <img src="../../imagens/12x.png" id="img_formas_de_pagamento" >

</div>


  <div>

    <a href="" onclick="calculador();enviar();" data-toggle="modal" data-target="#incluir_pct_p"><img src="../../imagens/carrinho_2.png" id="carrinho_fixo"></a>

    
    

  </div>

    <!--__________________________________________________________________________________-->



<!--  ________________________PRODUTOS___________________________  -->

		    <div id="margin_card" >

		
					<div>
						 <?php include($produtos); ?>
					</div>

		    </div>
<!--  ________________________________________________________________  -->





    <!-- Button trigger modal -->
    

    <!-- Modal -->
    <div class="modal fade" id="exampleModal"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    	<div class="modal-dialog">
    		<div class="modal-content"style="background-color: #fbfbea">

    			<div class="modal-header">
    				<h5 class="modal-title" id="exampleModalLabel">Calcular frete</h5>
    				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
    				Sair	<span aria-hidden="true">&times;</span>
    				</button>
    			</div>


    			<div class="modal-body">
    				<h5>Digite o seu <y style="color: blue"> CEP </y> para calcular o frete <img src="../../imagens/calcular.png" id="img_calculadora_frete"> </h5>
    				<div><br>
    					 
    			    <div class="opt" onCLick="window.open('http://www.buscacep.correios.com.br/sistemas/buscacep/','_blank');"><a href="" style="color: blue">Eu nao sei o meu CEP</a> </div>
    			    <br>
    				<input type="textnumber" name="calcular" id="cep_destino" placeholder="CEP Apenas números...">
            <a href="" data-toggle="modal" data-target="#modal_frete_msg"> <button  type="button" onclick="loadfrete();" class="btn btn-primary"> Calcular</button></a>
    				<img src="../../imagens/correio.png"id="img_correio">
    				</div><br>



          
         

            
      <div  class="modal fade" id="modal_frete_msg" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">


        <div class="modal-dialog" >
          <div class="modal-content"style="background-color: #d6d6d5">
            <div class="modal-header">
              <h5 class="modal-title" id="staticBackdropLabel"> Frete <img src="../../imagens/caminhao.png" id="img_btn_caminhao"> </h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">

              <div id="estilo_msg_frete" style="background-color: #eaeae8; border-radius: 5%;" >

               <div>

                <div style="padding: 20px">

                  <h5 style="color: #025300"> <output id="sucess"><y style="color: blue">Calculando...</y></output></h5>

                </div><br>

              </div>
            </div>

            </div>
            <div class="modal-footer">

              <img src="../../imagens/seta.png" id="img_seta">
              <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="calculador();enviar();">Continuar</button>
              
            </div>
          </div>
        </div>
  </div>
      


     






                   <div class="card card-body" style="background-color: #ededed">

                   

    				 <h6><li style="color: #ae142e"> O frete estipulado é pelo serviço <a href="https://www.rastreamentocorreios.inf.br/pac-correios/" > PAC (correios)</a>, o tempo de entrega é de até <b><u>15 dias uteis</u></b>.</h6><br>

                    
                     <div> <a href=""  type="button" data-toggle="collapse" data-target="#ver_mais-frete" aria-expanded="false" aria-controls="collapseExample">Ver mais...</a>
      

                   </div>
                    <div class="collapse" id="ver_mais-frete">
                        
                       
                        <a href="" style="color: red"  type="button" data-toggle="collapse" data-target="#ver_mais-frete" aria-expanded="false" aria-controls="collapseExample">X FECHAR</a>
                      <hr>
                      <h6> <li style="color:"> Para adicionar um ou mais itens no mesmo <y style="color: green"><u>frete</u> </y> clique em "incluir".</h6><br>

                       
                      <h6> <p align="justify">Possuímos envios alternativos como por exemplo SEDEX, empresas de ônibus, motoboys e etc. Para maiores esclarecimentos entre em contato pelo nosso whatsapp (61) 9 9262-0397 ou clique no link ao lado.</p>
                      Para maiores informações va até <a href="http://localhost/sistemas/tecnobaby/sistema/telas/index.php?acao=info">Informações</a>
                      </h6>
                    
                    </div>
                </div>



                     <h5></h5>
                    
    			</div>
    			<div class="modal-footer">

                    
                <button type="button" class="btn btn-danger" data-dismiss="modal"> Não calcular</button> 
    			
    		        

    			</div>
    		</div>
    	</div>
    </div>

  <script type="text/javascript" src="../javascript/compras_js/compra.js"></script> 
  <script type="text/javascript" src="../javascript/compras_js/Envios.js"></script>
  




