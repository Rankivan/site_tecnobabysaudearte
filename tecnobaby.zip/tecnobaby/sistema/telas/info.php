



    <img id="img_balao_info" src="../../imagens/img_informacoes.png">


<!--_################################################################-->


<div id="estilo_informacoes">



          <div class="accordion" id="accordionExample">

<!--_______________________________________________________________________________-->

<!--###############################################################################-->

              <div class="card">
                <div class="card-header" id="headingOne">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse1" aria-expanded="false" aria-controls="collapseOne">
                      <h6 style="color: #038c2a">Informações sobre a Tecnobaby</h6>
                    </button>
                  </h2>
                </div>

                <div id="collapse1" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div class="card-body">
                     <h6><p style="text-align: justify;">
                    A tecnobaby é uma empresa de CNPJ 280839360001, com a nossa central na cidade de Brasília-DF e o centro de distribuição em Gurupi-TO. Promovendo a produção de equipamentos lúdicos e infantis. Nós trabalhamos para garantir que nossos clientes recebam um produto de qualidade com rapidez e segurança, visando o melhor atendimento.
                    </p></h6>
                    <h6><p style="text-align: justify;"> Nossos produtos já foram testados e aprovados por diversos profissionais e pesquisadores da área da saúde em todo o Brasil. Toda a verba adiquirida com os nossos produtos são aplicadas em desenvolvimento e publicação de estudos científicos e criação de novos produtos.</p></h6>
                  </div>
                </div>
              </div>

<!--###############################################################################-->



              <div class="card">
                <div class="card-header" id="headingOne">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapseOne">
                      <h6 style="color: #038c2a"> Informações sobre os nossos produtos </h6>
                    </button>
                  </h2>
                </div>

                <div id="collapse2" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div class="card-body">


                                <div class="card">
                                  <div class="card-header" id="headingOne">
                                    <h2 class="mb-0">
                                      <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse2_1" aria-expanded="true" aria-controls="collapseOne">
                                        <h6> Sobre a estabilização protetora (pacotinho do bebê) </h6>
                                      </button>
                                    </h2>
                                  </div>

                                  <div id="collapse2_1" class="collapse" aria-labelledby="headingOne" >
                                    <div class="card-body">

                                     <h6><p style="text-align: justify;">
                                      É um dispositivo que permite, com proteção e segurança, controlar movimentos bruscos da criança com comportamento não colaborativo. Sabe-se que crianças muito novas podem apresentar dificuldade na colaboração de atendimentos mais invasivos como cirurgias ou endodontias no atendimento odontológico, e pode ser usado até mesmo para atendimentos de urgência médica no ambiente hospitalar ou ambulatorial.</p></h6>
                                      <h6><p style="text-align: justify;">
                                      ATENÇÃO: Se a criança for colaborativa e apresentar a possibilidade de ser condicionada psicologicamente ao atendimento, ou se o procedimento não precisar da limitação de movimentos, evitar o uso de qualquer dispositivo de restrição física!!!</p></h6>
                                      <h6><p style="text-align: justify;">
                                      É importante enfatizar que a estabilização protetora pode ser usada como medida terapêutica, porém com prudência para evitar a sua banalização, respeitando a idade e maturidade mental da criança, pois se utilizado sem as corretas indicações, pode acarretar danos físicos e psíquicos aos pacientes.</p></h6>


                                    </div>
                                  </div>
                                </div>



                                     <div class="card">
                                  <div class="card-header" id="headingOne">
                                    <h2 class="mb-0">
                                      <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse2_5" aria-expanded="true" aria-controls="collapseOne">
                                        <h6> O diferencial do pacotinho do bebê </h6>
                                      </button>
                                    </h2>
                                  </div>

                                  <div id="collapse2_5" class="collapse" aria-labelledby="headingOne" >
                                    <div class="card-body">

                                     <h6><p style="text-align: justify;">
                                     A única ESTABILIZAÇÃO PROTETORA da criança que promove eficiência e humanização Instrumento preparado e planejado por Doutores Pesquisadores da área infantil!
                                      Tudo para um atendimento com segurança e abordagem pensando no emocional da criança, pais e equipe médica e odontológica </p></h6>
                                      <h6><p style="text-align: justify;">
                                      Você já deve ter visto muitos produtos que prometem a mesma função que o nosso Pacotinho, então por que adquirir o nosso produto?
                                      </p></h6>
                                      <h6><p style="text-align: justify;">
                                      1- Foi desenvolvido de forma lúdica, por uma profissional Doutora em Odontopediatria. Já foi aprovado em vários congressos;
                                      </p></h6>
                                      <h6><p style="text-align: justify;">
                                      2- Já foi testado por profissionais da área durante anos, comprovando sua eficácia (ele realmente estabiliza a criança, sem o perigo de causar nenhum dano);
                                      </p></h6>
                                      <h6><p style="text-align: justify;">
                                      3- É confeccionado manualmente com todo amor e cuidado. Material resistente 100% algodão com feiches de velcro para abrir e fechar a peça;
                                      4- Possui 3 tamanhos (P,M,G) para atender crianças de 0 a 5 anos;
                                      </p></h6>
                                      <h6><p style="text-align: justify;">
                                      5- É todo trabalhado com estampas e cores alegres;
                                      </p></h6>
                                      <h6><p style="text-align: justify;">
                                      6- É o ÚNICO no mercado que possui decoração com "cabeça de bicho", (panda, leão e urso), podendo carinhosamente ser chamado de (abraço do pandinha, abraço do leãozinho e abraço do ursinho), tornando o atendimento mais HUMANIZADO.
                                      </p> </h6>
                                      <h6><p style="text-align: justify;">
                                      7- Com o uso desse dispositivo, a criança estará mais segura e confortável no atendimento do Pediatra ou Odontopediatra!
                                      </p>
</h6>


                                    </div>
                                  </div>
                                </div>

                                    <div class="card">
                                  <div class="card-header" id="headingOne">
                                    <h2 class="mb-0">
                                      <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse2_2" aria-expanded="true" aria-controls="collapseOne">
                                        <h6> Pacotinho P (0 a 1 ano e meio de idade) </h6>
                                      </button>
                                    </h2>
                                  </div>

                                  <div id="collapse2_2" class="collapse" aria-labelledby="headingOne" >
                                    <div class="card-body">

                                     <h6><p style="text-align: justify;">
                                      O tamanho P possui um desenho técnico para neutralizar pontos de forças das crianças de 0 a 1 ano e meio de idade. Este pacotinho P, oferece o "ABRAÇO DO PANDA" (a forma lúdica explicada para a mãe) e é muito indicado em exames médicos ou odontológicos para atendimentos de urgências, cirurgias, sedações ou procedimentos que necessitem da limitação dos movimentos do bebê. Lembrando que segurar o bebê, para evitar a movimentação durante os procedimentos, podem provocar hematomas ou machucar a criança.</p></h6>


                                    </div>
                                  </div>
                                </div>


                                <div class="card">
                                  <div class="card-header" id="headingOne">
                                    <h2 class="mb-0">
                                      <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse2_3" aria-expanded="true" aria-controls="collapseOne">
                                        <h6>Pacotinho M (1 ano e meio a 3 anos de idade) </h6>
                                      </button>
                                    </h2>
                                  </div>

                                  <div id="collapse2_3" class="collapse" aria-labelledby="headingOne" >
                                    <div class="card-body">

                                     <h6><p style="text-align: justify;">
                                      O tamanho M é de rápida estabilidade e possui um desenho técnico para neutralizar pontos de forças das crianças de 1 ano e meio a 3 anos de idade. Este pacotinho M, oferece o "ABRAÇO DO LEÃO" (a forma lúdica explicada para a mãe) e é muito indicado em exames médicos ou odontológicos para atendimentos de urgências, cirurgias, sedações ou procedimentos que necessitem da limitação dos movimentos do bebê. É confeccionado com tecido resistente de algodão, não provocando alergia e evita a hipertermia (calor exagerado). É autoclavável assim como os outros pacotinhos.</p></h6>


                                    </div>
                                  </div>
                                </div>


                               <div class="card">
                                  <div class="card-header" id="headingOne">
                                    <h2 class="mb-0">
                                      <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse2_4" aria-expanded="true" aria-controls="collapseOne">
                                        <h6>Pacotinho G (3 a 6 anos de idade) </h6>
                                      </button>
                                    </h2>
                                  </div>

                                  <div id="collapse2_4" class="collapse" aria-labelledby="headingOne" >
                                    <div class="card-body">

                                     <h6><p style="text-align: justify;">
                                      O Pacotinho do Bebê tamanho G foi idealizado para crianças de 3 a 6 anos. Ele é mais reforçado e foi todo estilizado para que seja confortável à criança e consiga anular todos os pontos de força, assim a criança não precisará ser segurada nem apertada pelas pessoas que estão na equipe, por isso ele tem faixas que são de espessura que não machucam a criança. É um dispositivo lúdico com desenhos e estampas alegres.</p></h6>


                                    </div>
                                  </div>
                                </div>



                  </div>
                </div>
              </div>


<!--########################################################################-->





              <div class="card">
                <div class="card-header" id="headingOne">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse3" aria-expanded="false" aria-controls="collapseOne">
                      <h6 style="color: #038c2a">Informações sobre a loja virtual</h6>
                    </button>
                  </h2>
                </div>

                <div id="collapse3" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div class="card-body">
                     <h6><p style="text-align: justify;"> 
                    Oferecemos aos nossos clientes o serviço de loja virtual, ou seja você pode adquirir, conhecer e vizualizar um produto que deseja no conforto do seu sofá! Para maiores esclarecimentos temos o nosso atendimento diferenciado pelos meios de comunicação: E-mail e WhatsApp, todos os dias uteis de segunda à sabado das 8 às 19 horas.

                  </p></h6>


                  <h6><p style="text-align: justify;"> 
                    
                  Para a segurança de nossos clientes, disponibilizamos o meio de pagamento através do PagSeguro, o qual permite que o comprador tenha segurança e rapidez na transação. Além disso existem maneiras seguras de reembolsos caso o cliente esteja insatisfeito entre outras vantagens. Caso queira conhecer mais <a href="https://pagseguro.uol.com.br/para_voce/passo_a_passo.jhtml#rmcl">clique aqui.</a>

                  </p></h6>



                    
                  </div>
                </div>
              </div>
              

<!--########################################################################-->





              <div class="card">
                <div class="card-header" id="headingOne">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse4" aria-expanded="false" aria-controls="collapseOne">
                      <h6 style="color: #ea2308">Tive um problema com a minha compra!</h6>
                    </button>
                  </h2>
                </div>  

                <div id="collapse4" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div class="card-body">

                  <h6><p style="text-align: justify;"> 
                    Se você tem uma dúvida ou algum problema relacionado com a compra de alguns de nossos produtos, entre em contato agora mesmo pelos nossos canais de atendimento WhatsApp, telefone {(61) 99262-0397} e/ou Facebook e Instagran. Respeitamos sériamente o código de defesa do consumidor e sempre queremos o melhor aos nossos clientes.
                  </p></h6>

                   <h6><p style="text-align: justify;">
                     Nós respondemos em dias uteis de <u>segunda a sábado dás 8 às 19 horas</u>.
                  </p></h6>
                



                  </div>
                </div>
              </div>




<!--_______________________________________________________________________________-->


<!--########################################################################-->





              <div class="card">
                <div class="card-header" id="headingOne">
                  <h2 class="mb-0">
                    <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse5" aria-expanded="false" aria-controls="collapseOne">
                      <h6 style="color: #038c2a">Frete, preços e prazos</h6>
                    </button>
                  </h2>
                </div>

                <div id="collapse5" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div class="card-body">


                  <h6><p style="text-align: justify;"> 
                    A tecnobaby Saúde e arte, de forma padrão, realiza o envio de seus produtos através do serviço PAC (Correios). Caso você tenha interesse em alterar o modo de envio ou gostaria de saber se há algum outro tipo de entrega, entre em contato e tire esta dúvida agora mesmo pelos nossos canais de atendimento WhatsApp, telefone {(61) 99262-0397} e/ou Facebook e Instagran.
                  </p></h6>
                    



                  </div>
                </div>
              </div>




<!--########################################################################-->







<!--_______________________________________________________________________________-->
      
            </div>



  
</div>
   