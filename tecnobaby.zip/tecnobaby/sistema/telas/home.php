

<div id="conteudo">


    <div >


    	<img src="../../imagens/seja_bem_vindo_2.png" id="nuvem_img">



    	

    </div > 

    




<div class="galeria_1" >

<img class="foto_1" id="img_1" src="../../imagens/tec_img/1.png" >
<img class="foto_1" id="img_1" src="../../imagens/tec_img/1_1.jpg" >
<img class="foto_1" id="img_1" src="../../imagens/tec_img/1_2.png" >
<img class="foto_1" id="img_1" src="../../imagens/tec_img/1_3.png" >

</div>

<div class="galeria_2" >

<img class="foto_2" id="img_2" src="../../imagens/tec_img/2.png" >
<img class="foto_2" id="img_2" src="../../imagens/tec_img/2_2.png" >
<img class="foto_2" id="img_2" src="../../imagens/tec_img/2_3.png" >
<img class="foto_2" id="img_2" src="../../imagens/tec_img/2_4.png" >
<img class="foto_2" id="img_2" src="../../imagens/tec_img/2_5.png" >
	
	

</div>

<div class="galeria_3" >

	 <img class="foto_3" id="img_3" src="../../imagens/tec_img/3.png" >
	 <img class="foto_3" id="img_3" src="../../imagens/tec_img/3_1.png" >
	 <img class="foto_3" id="img_3" src="../../imagens/tec_img/3_2.png" >
	 <img class="foto_3" id="img_3" src="../../imagens/tec_img/3_3.png" >
	 <img class="foto_3" id="img_3" src="../../imagens/tec_img/3_4.png" >
	 
	

</div>

<div>

	<img id="info" src="../../imagens/tec_img/descricao.png">


	<div id="texto" >
		<h5><p align="justify">  &nbsp &nbsp Somos a Tecnobaby Saúde & Arte, nossa empresa é formada por uma equipe que estuda e pesquisa produtos domésticos e hospitalares com a missão de oferecer qualidade e segurança no atendimento em Saúde Infantil, PcD’s (pessoas com deficiência), jovens e adultos. Nós trabalhamos para garantir que nossos clientes recebam um produto de qualidade com rapidez e segurança, visando o melhor atendimento. Nossos produtos já foram testados e aprovados por diversos profissionais e pesquisadores da área da saúde em todo o Brasil. Toda a verba adiquirida com os nossos produtos são aplicadas em desenvolvimento e publicação de estudos científicos e criação de novos produtos.</p></h5>
	</div>


	

</div>

	




</div>




<br>




    