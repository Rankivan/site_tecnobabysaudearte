
 <?php

  $modal_finalizar_pedido = 'atr_compras/atr_carrinho/modal_finalizar_pedido.php';


  
  ?>



          <!-- MODAL INCLUIR -->


			<div class="modal fade" id="incluir_pct_p" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
			  <div class="modal-dialog">
			    <div class="modal-content"style="background-color: #e4e4e5">
			      <div class="modal-header">
			        <h5 class="modal-title" id="staticBackdropLabel" style="margin-left: 40px;"> Carrinho de compras </h5>
			        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			          <span aria-hidden="true">&times;</span>
			        </button>
			      </div>

             <div id="text_2" style="padding-top: 20px;"> <h6> Seu carrinho está vazio! <img id="carrinho_vazio"src="../../imagens/carrinho_vazio.png"> </h6></div>

			      <div class="modal-body" id="padding_carrinho_compras">
                   
               <div align="left" >


                    

       
            <div id="div_prod_pct_p"> 
              <table class="table jumbotron table-striped table-hover table-condensed table-bordered" style="text-align: center"id="tabela_estilo">
                <thead>
                  <tr>
                      <td><h6> Pacotinho tamanho "P"</h6></td>                           
                             <td> 
                                <a type="button" onclick="pord_pct_p ();calculador();"> 
                                  <input style="width: 40px; text-align: center" id="qtd_prod_pct_p" value ="1" readonly=“true”>                                
                                  </input> 
                                  </a> 
                                    <div id="div_adicionar_prd"  >
                                  <a href="#" type="button" onclick="adicionar_p();pord_pct_p();"  style="color: green">
                                    <img id="img_adicionar_prod_2" src="../../imagens/adicionar_prod.png">
                                  </a>
                                  <a href="#" type="button" onclick="diminuir_p();pord_pct_p();"  style="color: green">
                                    <img id="img_adicionar_prod_2" src="../../imagens/menos.png">
                                  </a>
                
                                </div>
                             </td>                             
                            <td>
                             <a href="#"  onclick="excluir_pord_pct_p();calculador();"><img id="img_excluir_prod" src="../../imagens/excluir.png"></a>
                            </td>
                     </tr>
                               <input  value="0" type="hidden" id="valor_prod_pct_p" />
                               <input  value="0" type="hidden" id="qtd_prod_pct_p_output">
                               <input  value="0" type="hidden" id="peso_pct_p"     />
                               <input  value="0" type="hidden" id="dimensao_pct_p" />
                  </thead>
                </table>      
            </div>
        



                    <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                     <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->


                      
            <div id="padding_teto" >
             <div id="div_prod_pct_m"> 
              <table class="table jumbotron table-striped table-hover table-condensed table-bordered" style="text-align: center"id="tabela_estilo">
                <thead>
                  <tr>
                      <td><h6>Pacotinho tamanho "M"</h6></td>                           
                           <td> 
                                <a type="button" onclick="pord_pct_m ();calculador();"> 
                                  <input style="width: 40px; text-align: center" id="qtd_prod_pct_m" value ="1" readonly=“true”>                                
                                  </input> 
                                  </a> 
                                    <div id="div_adicionar_prd"  >
                                  <a href="#" type="button" onclick="adicionar_m();pord_pct_m();"  style="color: green">
                                    <img id="img_adicionar_prod_2" src="../../imagens/adicionar_prod.png">
                                  </a>
                                  <a href="#" type="button" onclick="diminuir_m();pord_pct_m();"  style="color: green">
                                    <img id="img_adicionar_prod_2" src="../../imagens/menos.png">
                                  </a>
                
                                </div>
                             </td>                              
                            <td>
                             <a href="#"  onclick="excluir_pord_pct_m();calculador();"><img id="img_excluir_prod" src="../../imagens/excluir.png"></a>
                            </td>
                     </tr>
                               <input  value="0" type="hidden" id="valor_prod_pct_m" />
                               <input  value="0" type="hidden" id="qtd_prod_pct_m_output">
                               <input  value="0" type="hidden" id="peso_pct_m"     />
                               <input  value="0" type="hidden" id="dimensao_pct_m" />
                  </thead>
                </table>      
            </div>
          </div>  




                    <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                     <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                     <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->


                      
           <div id="padding_teto">
             <div id="div_prod_pct_g"> 
              <table class="table jumbotron table-striped table-hover table-condensed table-bordered" style="text-align: center"id="tabela_estilo">
                <thead>
                  <tr>
                      <td><h6>Pacotinho tamanho "G"</h6></td>                           
                              <td> 
                                <a type="button" onclick="pord_pct_g ();calculador();"> 
                                  <input style="width: 40px; text-align: center" id="qtd_prod_pct_g" value ="1" readonly=“true”>                                
                                  </input> 
                                  </a> 
                                    <div id="div_adicionar_prd"  >
                                  <a href="#" type="button" onclick="adicionar_g();pord_pct_g();"  style="color: green">
                                    <img id="img_adicionar_prod_2" src="../../imagens/adicionar_prod.png">
                                  </a>
                                  <a href="#" type="button" onclick="diminuir_g();pord_pct_g();"  style="color: green">
                                    <img id="img_adicionar_prod_2" src="../../imagens/menos.png">
                                  </a>
                
                                </div>
                             </td>                            
                            <td>
                             <a href="#"  onclick="excluir_pord_pct_g();calculador();"><img id="img_excluir_prod" src="../../imagens/excluir.png"></a>
                            </td>
                     </tr>
                               <input  value="0" type="hidden" id="valor_prod_pct_g" />
                               <input  value="0" type="hidden" id="qtd_prod_pct_g_output">
                               <input  value="0" type="hidden" id="peso_pct_g"     />
                               <input  value="0" type="hidden" id="dimensao_pct_g" />
                  </thead>
                </table>      
            </div>
           </div> 








                     <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                     <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->


                      
            <div id="padding_teto">
             <div id="div_prod_pct_kit"> 
              <table class="table jumbotron table-striped table-hover table-condensed table-bordered" style="text-align: center" id="tabela_estilo">
                <thead>
                  <tr>
                      <td><h6> KIT pacotinho (P, M e G)</h6></td>                           
                             <td> 
                                <a type="button" onclick="pord_pct_kit ();calculador();"> 
                                  <input style="width: 40px; text-align: center" id="qtd_prod_pct_kit" value ="1" readonly=“true”>                                
                                  </input> 
                                  </a> 
                                    <div id="div_adicionar_prd"  >
                                  <a href="#" type="button" onclick="adicionar_kit();pord_pct_kit();"  style="color: green">
                                    <img id="img_adicionar_prod_2" src="../../imagens/adicionar_prod.png">
                                  </a>
                                  <a href="#" type="button" onclick="diminuir_kit();pord_pct_kit();"  style="color: green">
                                    <img id="img_adicionar_prod_2" src="../../imagens/menos.png">
                                  </a>
                
                                </div>
                             </td>                            
                            <td>
                             <a href="#"  onclick="excluir_pord_pct_kit();calculador();"><img id="img_excluir_prod" src="../../imagens/excluir.png"></a>
                            </td>
                     </tr>
                               <input  value="0" type="hidden" id="valor_prod_pct_kit" />
                               <input  value="0" type="hidden" id="qtd_prod_pct_kit_output">
                               <input  value="0" type="hidden" id="peso_pct_kit"     />
                               <input  value="0" type="hidden" id="dimensao_pct_kit" />
                  </thead>
                </table>      
            </div>
           </div> 




                      <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                      <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                      <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                      <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->

        
			        
             </div>

                <hr>
                   <div align="left">

                             <h5 style="color: blue"><p><img src="../../imagens/caminhao_2.png"id="img_dinheiro"> Frete = <input value="0" type="hidden" id="valor_frete_3"/><output type="" value="0" id="frete_total"> </output> 

                                     <input value="0" type="hidden" id="cep_invalido_boolean">
                                     <input type="hidden" value="0" id="exibir_msg_frete_invalido"/>

                                       <div id="cep_invalido" style="color: #a10707"><p>Este CEP é inválido!</p> Favor clique abaixo e insira um CEP <u>válido!</u></div>
                            
                                      <div id="frete_nao_calculado_3">
                                       <a href="" data-toggle="modal" data-target="#exampleModal">Quero calcular o meu frete</a></div>

                                       <div id="frete_calculado_3">
                                       <a href="" data-toggle="modal" data-target="#exampleModal">Modificar o meu frete</a></div>

                                      </h5> </h5> 
                                       
                                       </div>
                                       <hr>
                                       <div align="left">
                                       <h5> Total = <output id="total_final"></output> </h5><hr>

                   </div>


   



       <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->

        <form id ="comprar" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post" >  <!-- onsubmit="PagSeguroLightbox(this); return false;"  -->
      
        <input type="hidden" name="code" id="code" value="" />
    
        </form>

     
       <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->


          <div align="left" id="btn_finalizar_compra">

              <input type="hidden" id="total_final_3" name="">


                 <div id="recalcular_valor_qtd">


                                    <a href="#" type="button" onclick="atualizar_valores();calculador();"  style="color: green">

                                     <span> <h6>Atualizar valor 

                                    <img  src="../../imagens/atualizar.png" style="width:20px; height: 20px;"></h6></span>
                                  </a>

               </div>

               

              <button id="btn_finalizar_compra_2" class="btn btn-success" onclick="calculador();enviar();" data-toggle="modal" data-target="#modal_finalizar_compra"> Finalizar compra </button>

             


           <div id="margin_continuar_compra">
              <button id="btn_continuar_compra_2" type="button" class="btn btn-primary" data-dismiss="modal">Continuar comprando</button>
           </div>

         </div>

                 <div>
                  <button id="inserir_prod_no_carr" type="button" class="btn btn-primary" data-dismiss="modal">Insira um produto</button>
                   

                 </div>


			      </div>
			    </div>
			  </div>
			</div>

      



           <div>
             <?php include($modal_finalizar_pedido); ?>
          </div>


   
    



    <script type="text/javascript" src="../javascript/compras_js/atr_compras_js/CAlCULAdora.js"></script>
    <script type="text/javascript" src="../javascript/compras_js/atr_compras_js/mensagem_frete_invalido.js"></script>
    <script type="text/javascript" src="../javascript/compras_js/atr_compras_js/VALoreS_info.js"></script>

    <script type="text/javascript" src="https://stc.pagseguro.uol.com.br/pagseguro/api/v2/checkout/pagseguro.lightbox.js"></script>


    <script type="text/javascript" src="../javascript/compras_js/atr_compras_js/FiNALizar_compra.js"></script>
    <script type="text/javascript" src="../javascript/compras_js/atr_compras_js/FOrmulario_sem_freteajax.js"></script>