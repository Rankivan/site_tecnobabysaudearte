







   <div class="modal fade" data-backdrop="static" id="modal_finalizar_compra" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Finalizar compra <img src="../../imagens/menino.png" style="width: 50px; height: 50px;"></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">

                         <div id="frete_nao_calculado" >
                          
                          <h5>Frete <y style="color: red"> NÃO </y> calculado!</h5>

                         <h6> <p align="justify">O seu <u>frete não foi inserido</u>, caso queira comprar sem o frete e retirar com o vendedor ou algum outro motivo aparente, clique em "Comprar sem calcular o frete", ou calcule o frete abaixo.</p></h6>

                          <h5><a href="" data-toggle="modal" data-target="#exampleModal">Quero calcular o meu frete</a></h5>
                      </div>



                         <div >

                         
                          <div id="cadastro">
                            <div align="left">

                              <form>

                             

                              <input type="hidden" id="descricao_p">
                              <input type="hidden" id="descricao_m">
                              <input type="hidden" id="descricao_g">
                              <input type="hidden" id="descricao_kit">
                              <input type="hidden" id="frete_output">



                        <!--      <input type="text" class="form-control" id="nome_completo"
                      onblur="formatanome(this.value)" placeholder="Nome completo..."> -->

                                 <div id="msg_campo_vazio_1" align="center" style="color: red">

                                   <h6>Preencha <u>todos</u> os campos</h6> 
                                    
                                  </div>


                                  <label><h5>Nome completo:</h5></label><br>
                                  <input type="text" class="form-control"  id="nome_cadastro" placeholder="Digite seu nome..." onblur="letra_nome(this.value)"><br><br>

                                  <label><h5>CPF:</h5></label><br>
                                  <input type="" class="form-control" id="cpf_cadastro" placeholder="Digite seu CPF..."onblur="cpf(this.value)"><br><br>

                                  <label><h5>Endereço de entrega:</h5></label><br>
                                  <textarea type="" class="form-control" id="endereco_cadastro" placeholder="Exemplo: Avenida São Paulo...."onblur="letra_endereco(this.value)"></textarea><br><br>

                                  <label><h5> Cidade </h5></label><br>
                                  <input type="" class="form-control" id="cidade_cadastro" placeholder="Nome da sua cidade..."onblur="letra_cidade(this.value)"><br><br>

                                  <label><h5> Estado</h5></label><br>
                                  <input type="" class="form-control" id="estado_cadastro" placeholder="Seu estado..."onblur="letra_estado(this.value)"><br><br>

                                  <h5><label><h5>CEP:</h5></label>
                                  <output style="color: blue" id="cep_output"></output></h5>

                                  <input type="hidden" class="form-control" id="cep_output_2">

                                  <label><h5>Telefone para contato:</h5></label><br>
                                  <input type="" class="form-control" id="telefone_cadastro" placeholder="(61)99262..." onblur="telefone_contato(this.value)"><br><br>

                                  <label><h5>E-mail:</h5></label><br>
                                  <input onblur="email_contato(this.value)" type="" class="form-control" id="email_cadastro" placeholder="Ex: joao@hotmail.com"><br><br>

                                  <input type="hidden" value="0" id="soma_1" name="">


                                  <div  id = "msg_email_1" align="center" > <hr>


                                   <h6 style="color: green"> Ótimo, <u>preencheu tudo?</u> Após isto <a href="#"><y style ="color: blue"> clique aqui </y></a> e depois em "continuar"</h6>
                                    

                                  </div>

                              

                              </form>



                             </div> 
                          </div>
                          

                          <div id="frete_calculado">
                                <p align="justify">

                                <h5> Você será redirecionado para o <u>pag seguro</u>, lá poderá efetuar o pagamento em total segurança!</p></h5>
                                 <h7><p> A tecnobaby agradece!!! </p></h7>
                                 <h6>Clique em "ok" para continuar..."</h6>

                           </div>

                          </div>


                      
                      </div>
                      <div class="modal-footer">

                         <div id="frete_nao_calculado_2">
                          <button  class="btn btn-warning" data-toggle="modal" data-target="#modal_sem_frete" > <h5>Comprar e retirar com o vendedor</h5> </button> 
                        </div>
                         <div id="frete_calculado_2">
                          <button  class="btn btn-success" onclick="finalizar_compra();calculador();" > OK </button> 
                          </div>

                          <div id="btn_enviar_cadastro_1">
                          <div id="btn_cadastro">
                          <button  class="btn btn-success" onclick="cadastrar_1();cadastro();" > Enviar cadastro </button> 
                          </div>

                          </div>
                     
                      </div>
                    </div>
                  </div>
                </div>


                   
                            <!-- Modal -->
                            <div class="modal fade" data-backdrop="static" id="modal_sem_frete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Compra <u>sem frete</u> <img src="../../imagens/menino.png" style="width: 50px; height: 50px;"></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body" align="left">



                                  <div id="msg_campo_vazio" align="center" style="color: red">

                                   <h6>Preencha <u>todos</u> os campos</h6> 
                                    
                                  </div>



                                  <label><h5>Nome completo:</h5></label><br>
                                  <input type=""  id="nome_cadastro_2" placeholder="Digite seu nome..."onblur="letra_nome_2(this.value)"><br><br>

                                  <label><h5>CPF:</h5></label><br>
                                  <input onblur="cpf_2(this.value)" type=""  id="cpf_cadastro_2" placeholder="Digite seu CPF..."><br><br>

                                  <label><h5>Telefone para contato:</h5></label><br>
                                  <input onblur="telefone_contato_2(this.value)" type="" id="telefone_cadastro_2" placeholder="(61)99262..."><br><br>


                                  <label><h5>E-mail:</h5></label><br>
                                  <input onblur="email_contato_2(this.value)" type="" id="email_cadastro_2" placeholder="Ex: joao@hotmail.com"><br><br>

                                  <div id = "msg_email_2" align="center" > <hr>


                                   <h6 style="color: green"> Ótimo, <u>preencheu tudo?</u> Após isto <a href="#"><y style ="color: blue"> clique aqui </y></a> e depois em "continuar"</h6>
                                    

                                  </div>


                                  <input type="hidden" id="soma_2" value="0">


                                  <input type="hidden" id="descricao_p_2">
                                  <input type="hidden" id="descricao_m_2">
                                  <input type="hidden" id="descricao_g_2">
                                  <input type="hidden" id="descricao_kit_2">
                                  


                                   

                               
                                  </div>
                                 <div id="btn_enviar_cadastro_2" class="modal-footer"> 
                                    
                                   <button onclick="cadastra_form_2();"type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal_finalizar_compra_sem_frete"> Enviar cadastro </button>
                               </div>
                                </div>
                              </div>
                            </div>



                              <!-- ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||-->






                                          
                                        <div class="modal fade" id="modal_finalizar_compra_sem_frete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog">
                                            <div class="modal-content">
                                              <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Compra <u>sem frete</u><img src="../../imagens/menino.png" style="width: 50px; height: 50px;"></h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                  <span aria-hidden="true">&times;</span>
                                                </button>
                                              </div>
                                              <div class="modal-body" align="left">


                                             <div id="frete_calculado">
                                            <p align="justify">

                                            <h5> Você será redirecionado para o <u>pag seguro</u>, lá poderá efetuar o pagamento em total segurança!</p></h5>
                                             <h7><p> A tecnobaby agradece!!! </p></h7>
                                             <h6>Clique em "ok" para continuar..."</h6>

                                            </div>



                                           
                                              </div>
                                              <div class="modal-footer">

                                              <div id="frete_calculado_2">
                                              <button  class="btn btn-success" onclick="finalizar_compra();calculador();" > OK </button> 
                                              </div>
                                                
                                             
                                              </div>
                                            </div>
                                          </div>
                                        </div>

                                 <!--/onclick="finalizar_compra();"/ -->


     <script type="text/javascript" src="../javascript/compras_js/atr_compras_js/form_com_frete.js"></script>

     <script type="text/javascript" src="../javascript/compras_js/atr_compras_js/form_sem_frete.js"></script>

     <script type="text/javascript" src="../javascript/compras_js/atr_compras_js/MASCAra_formularios.js"></script>