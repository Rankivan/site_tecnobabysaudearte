





<!--  ________________________PACOTINHO P___________________________  -->


		<div class="row" >
			
			<div class="col-md-6 col-sm-12" id="card_tela_pequena" style="padding: 20px" >
				<div class="card">
					<div class="card-body ">
						<h5 class="card-title">Pacotinho-P</h5>


						<p class="card-text"><h6> Indicação (0 a 1 ano e meio de idade)</h6></p>
						<hr>

						<img src="../../imagens/tec_img/P.png" id="img_produto" >
						<hr>

						<div>

                         
						<h5 style="color: green"><img src="../../imagens/dinheiro.png" id="img_dinheiro">
                         R$ 250,00 </h5>
                        <h5> 



					    </div>
					    <hr>
					    <div id="botoes" align="center">
								<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#prod_pacot_P">Ver mais...</button>

								<!-- MODAL VER MAIS -->
                                 <?php include($ver_mais); ?>


						<a href="#" type="button" onclick="pord_pct_p();calculador();enviar();" class="btn btn-success" data-toggle="modal" data-target="#incluir_pct_p" > Incluir <img src="../../imagens/adicionar_carrinho.png" style="width: 20px ; height: 20px; "></a><br>

						<!-- MODAL INCLUIR -->
						<?php include($carrinho_de_compras); ?>




						</div>
					</div>
				</div>
			</div>

	<!--  ________________________________________________________________  -->
	<!--  ________________________________________________________________  -->




     <!--  ________________________PACOTINHO M___________________________  -->

			<div class="col-md-6 col-sm-12" id="card_tela_pequena"style="padding: 20px">
				<div class="card">
					<div class="card-body">
					<h5 class="card-title">Pacotinho-M</h5>


						<p class="card-text"><h6>Indicação (1 ano e meio a 3 anos de idade).</h6></p>
						<hr>

						<img src="../../imagens/tec_img/M.png" id="img_produto" >
						<hr>

							<div>

                         
						<h5 style="color: green">
							<img src="../../imagens/dinheiro.png" id="img_dinheiro">
                         R$ 270,00 </h5>
                         

					    </div>
						 <hr> <div id="botoes" align="center">
						

								<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#prod_pacot_M">Ver mais...</button>

										<!-- Modal -->
										 <?php include($ver_mais); ?>
									
									
                            <a href="#" class="btn btn-success" class="btn btn-primary" data-toggle="modal" data-target="#incluir_pct_p"onclick="pord_pct_m();calculador();enviar();">Incluir <img src="../../imagens/adicionar_carrinho.png" style="width: 20px ; height: 20px; "></a><br>

										<!-- MODAL INCLUIR -->
										<?php include($carrinho_de_compras); ?>

                          
						</div>
					</div>
				</div>
			</div>


	<!--  ________________________________________________________________  -->
	<!--  ________________________________________________________________  -->




	<!--  ________________________PACOTINHO G___________________________  -->



				<div class="col-md-6 col-sm-12" id="card_tela_pequena"style="padding: 20px">
				<div class="card">
					<div class="card-body">
						<h5 class="card-title">Pacotinho-G</h5>


						<p class="card-text"><h6>Indicação (3 a 6 anos de idade).</h6></p>
						<hr>

						<img src="../../imagens/tec_img/G.png" id="img_produto" >
						<hr>

						<div>

                         
						<h5 style="color: green"><img src="../../imagens/dinheiro.png" id="img_dinheiro">
                         R$ 290,00 </h5>
                         

					    </div>
						 <hr> <div id="botoes" align="center">
												<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#prod_pacot_G">Ver mais...</button>

										<!-- Modal -->
										<?php include($ver_mais); ?>
									
                            <a href="#" class="btn btn-success" class="btn btn-primary" data-toggle="modal" data-target="#incluir_pct_p" onclick="pord_pct_g();calculador();enviar();">Incluir <img src="../../imagens/adicionar_carrinho.png" style="width: 20px ; height: 20px; "></a><br>

										<!-- MODAL INCLUIR -->
										<?php include($carrinho_de_compras); ?>


						</div>
					</div>
				</div>
			</div>


	<!--  ________________________________________________________________  -->
    <!--  ________________________________________________________________  -->



    <!--  ________________________PACOTINHO KIT___________________________  -->

			<div class="col-md-6 col-sm-12" id="card_tela_pequena"style="padding: 20px">
				<div class="card">
					<div class="card-body">
						<h5 class="card-title">Pacotinho-Kit completo (P, M e G).</h5>


						<p class="card-text"><h6> P M G ( 0 a 6 anos de idade).</h6></p>
						<hr>

						<img src="../../imagens/tec_img/KIT.png" id="img_produto" >
						<hr>

					    <div>

                         
						<h5 style="color: green"><img src="../../imagens/dinheiro.png" id="img_dinheiro">
                         R$ 650,00</h5>
                         
                           

					    </div>
						 <hr> 
						<div id="botoes" align="center">
						<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#prod_pacot_kit">Ver mais...</button>

										<!-- Modal -->
									


                            <a href="#" class="btn btn-success" class="btn btn-primary" data-toggle="modal" data-target="#incluir_pct_p" onclick="pord_pct_kit();calculador();enviar();">Incluir <img src="../../imagens/adicionar_carrinho.png" style="width: 20px ; height: 20px; "></a><br>

										<!-- MODAL INCLUIR -->
										<?php include($carrinho_de_compras); ?>

						</div>
					</div>
				</div>
			</div>

		</div>

	<!--  ________________________________________________________________  -->
    <!--  ________________________________________________________________  -->

  