
       
<div>
    
    <div style="background-color: black">

      	<div>
      		
      		<img src="" id="img_slide_g" class="img_slide">

      	</div>

      	<div class="passador_anter" id="anterior" onclick="anterior_g();"><</div>
      	<div class="passador_prox"  id="proximo" onclick="proximo_g();">></div>
      	
    </div>

      <ul id="botoes">
      	
      </ul>

</div>



 
<script type="text/javascript" src="../javascript/compras_js/atr_compras_js/PCT_g_Slide.js"></script>
    