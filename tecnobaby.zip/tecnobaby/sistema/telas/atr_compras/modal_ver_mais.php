







<!-- ____________________________________P_______________________________________________-->

				
				  <div class="modal fade" id="prod_pacot_P" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"data-backdrop="static">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title" id="exampleModalLabel">PACOTINHO P</h5>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
								</div>
								<div class="modal-body" style="padding: 10px"><h6><p align="justify">

									&nbsp O tamanho P possui um desenho técnico para neutralizar pontos de forças das crianças de 0 a 1 ano e meio de idade. Este pacotinho P, oferece o "ABRAÇO DO PANDA" (a forma lúdica explicada para a mãe) e é muito indicado em exames médicos ou odontológicos para atendimentos de urgências, cirurgias, sedações ou procedimentos que necessitem da limitação dos movimentos do bebê. Lembrando que segurar o bebê, para evitar a movimentação durante os procedimentos, podem provocar hematomas ou machucar a criança. <a href="#" type="button" data-toggle="collapse" data-target="#ver_mais_pct_p" aria-expanded="false" aria-controls="collapseExample">
									 Ver mais...</a>  </p></h6> 


									 <div class="collapse" id="ver_mais_pct_p" >
									 	<a style="color: red" href="#" type="button" data-toggle="collapse" data-target="#ver_mais_pct_p" aria-expanded="false" aria-controls="collapseExample">
									|X|Fechar</a> 
									  <div class="card card-body">


									   <h6><p align="left" >
										 <li align="left">A recomendação de uso é para crianças entre 0 até 1 ano e meio de idade.</li> <br>
										 <li align="left">Consulte os modelos disponiveis e as suas respectivas disponibilidades.</li><br>
										  <li align="left"> Tecido resistente </li><br>
										 <li align="left">Tecido 100% algodão.</li><br>
										 <li align="left">Permite ser aquecido até 150°C.</li><br>
										 <li align="left">Produto autoclavável.</li>



										</p></h6>

									  </div>
									</div>				
								</div>

								<div id="slide_ver_mais">
									
                                <!--  slide Pacotinho P  -->
                               <?php include($slide_pct_p); ?>
									
								</div>
								
								<div class="modal-footer">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
									
								</div>
							</div>
						</div>
					</div>
				



					<!-- _____________________________-->



     <!-- _____________________________________M___________________________________-->


					<div class="modal fade" id="prod_pacot_M" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"data-backdrop="static">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title" id="exampleModalLabel">Pacotinho M</h5>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
								</div>
							<div class="modal-body" style="padding: 10px"><h6><p align="justify">

									&nbsp O tamanho M é de rápida estabilidade e possui um desenho técnico para neutralizar pontos de forças das crianças de 1 ano e meio a 3 anos de idade. Este pacotinho M, oferece o "ABRAÇO DO LEÃO" (a forma lúdica explicada para a mãe) e é muito indicado em exames médicos ou odontológicos para atendimentos de urgências, cirurgias, sedações ou procedimentos que necessitem da limitação dos movimentos do bebê. É confeccionado com tecido resistente de algodão, não provocando alergia e evita a hipertermia (calor exagerado). É autoclavável assim como os outros pacotinhos. <a href="#" type="button" data-toggle="collapse" data-target="#ver_mais_pct_m" aria-expanded="false" aria-controls="collapseExample">
									 Ver mais...</a>  </p></h6> 


									 <div class="collapse" id="ver_mais_pct_m" >
									 	<a style="color: red" href="#" type="button" data-toggle="collapse" data-target="#ver_mais_pct_m" aria-expanded="false" aria-controls="collapseExample">
									|X|Fechar</a> 
									  <div class="card card-body">


									   <h6><p align="left" >

										 <li align="left">A recomendação de uso é para crianças entre 1 ano e meio a 3 anos de idade.</li> <br>
										 <li align="left">Consulte os modelos disponiveis e as suas respectivas disponibilidades.</li><br>
										 <li align="left">Tecido 100% algodão.</li><br>
										  <li align="left"> Tecido resistente </li><br>
										 <li align="left">Permite ser aquecido até 150°C.</li><br>
										 <li align="left">Produto autoclavável.</li>

										</h6>

									  </div>
									</div>				
								</div>

								<div >
									
                                <!--  slide Pacotinho P  -->
                               <?php include($slide_pct_m); ?>
									
								</div>
							     <div class="modal-footer">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
									<br>
								</div>
							</div>
						</div>
					</div>


					<!-- _____________________________-->




<!-- ______________________________________G_____________________________________-->



					<div class="modal fade" id="prod_pacot_G" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"data-backdrop="static">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title" id="exampleModalLabel">Pacotinho G</h5>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
								</div>
								<div class="modal-body" style="padding: 10px"><h6><p align="justify">

									&nbsp O Pacotinho do Bebê tamanho G foi idealizado para crianças de 3 a 6 anos. Ele é mais reforçado e foi todo estilizado para que seja confortável à criança e consiga anular todos os pontos de força, assim a criança não precisará ser segurada nem apertada pelas pessoas que estão na equipe, por isso ele tem faixas que são de espessura que não machucam a criança. É um dispositivo lúdico com desenhos e estampas alegres. <a href="#" type="button" data-toggle="collapse" data-target="#ver_mais_pct_g" aria-expanded="false" aria-controls="collapseExample">
									 Ver mais...</a>  </p></h6> 


									 <div class="collapse" id="ver_mais_pct_g" >
									 	<a style="color: red" href="#" type="button" data-toggle="collapse" data-target="#ver_mais_pct_g" aria-expanded="false" aria-controls="collapseExample">
									|X|Fechar</a> 
									  <div class="card card-body">


									   <h6><p align="left" >

										 <li align="left">A recomendação de uso é para crianças entre 3 a 6 anos de idade.</li> <br>
										 <li align="left">Consulte os modelos disponiveis e as suas respectivas disponibilidades.</li><br>
										 <li align="left">Tecido 100% algodão.</li><br>
										  <li align="left"> Tecido resistente </li><br>
										 <li align="left">Permite ser aquecido até 150°C.</li><br>
										 <li align="left">Produto autoclavável.</li>

										</h6>

									  </div>
								   </div>				
								</div>

								<div>
									 <?php include($slide_pct_g); ?>


								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
									
								</div>
							</div>
						</div>
					</div>

					<!-- _____________________________-->

<!-- ______________________________________Kit_P_M_G_____________________________________-->



					<div class="modal fade" id="prod_pacot_kit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"data-backdrop="static">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title" id="exampleModalLabel"> KIT pacotinhos (P, M e G)</h5>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
								</div>
								<div class="modal-body" style="padding: 10px"><h6><p align="justify">

									&nbsp O Kit P, M e G é o kit desenvolvido especialmete para você, que necessita de atender com segurança, pacientes de 1 até 6 anos de idade. <a href="#" type="button" data-toggle="collapse" data-target="#ver_mais_pct_kit" aria-expanded="false" aria-controls="collapseExample">
									 Ver mais...</a>  </p></h6> 


									 <div class="collapse" id="ver_mais_pct_kit" >
									 <a style="color: red" href="#" type="button" data-toggle="collapse" data-target="#ver_mais_pct_kit" aria-expanded="false" aria-controls="collapseExample">
									|X|Fechar</a> 
									  <div class="card card-body">


									   <h6><p align="left" >

										 <li align="left">A recomendação de uso é para crianças entre 0 até 6 anos de idade.</li> <br>
										 <li align="left">Consulte os modelos disponiveis e as suas respectivas disponibilidades.</li><br>
										 <li align="left">Tecido 100% algodão.</li><br>
										 <li align="left"> Tecido resistente </li><br>
										 <li align="left">Permite ser aquecido até 150°C.</li><br>
										 <li align="left">Produto autoclavável.</li>

									  </div>
									</div>				
								</div>

								<div>
									 <?php include($slide_pct_kit); ?>


								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
									
								</div>
							</div>
						</div>
					</div>
