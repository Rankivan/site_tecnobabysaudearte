



<?php 

     $menu_1 = 'home';
     $menu_2 = 'compras';
     $menu_3 = 'contato';
     $menu_4 = 'info';
    


    // Verifica se o menu está ativo


              if (@$_GET['acao'] == $menu_1 ) {   
              $menu_1_ativo = 'active';}

              elseif (@$_GET['acao'] == $menu_2 or isset($_GET['$menu_2']) ) {
              $menu_2_ativo = 'active';}

              elseif (@$_GET['acao'] == $menu_3 ) {
              $menu_3_ativo = 'active';}

              elseif (@$_GET['acao'] == $menu_4 ) {
              $menu_4_ativo = 'active';}

               else { 

              $menu_1_ativo = 'active';

             }

    ?>





<!DOCTYPE html>
<html>
    <head>


    <title> Home Tecnobaby </title>

    <meta charset="UTF-8">


       <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
       <script src ="operacao.js">  //Código em Java script </script>
       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>



       
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"> </script>


        <!-- bootstrap - link cdn -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"> <!-- Este é o link que chama o bootstrap-->

        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" >

        
        <link rel="stylesheet" type="text/css" href="../estilos/estilo_Index.css">
        <link rel="stylesheet" type="text/css" href="../estilos/estilo_Home.css">
        <link rel="stylesheet" type="text/css" href="../estilos/estilo_comprA.css">
        <link rel="stylesheet" type="text/css" href="../estilos/Estilo_info.css">
        <link rel="stylesheet" type="text/css" href="../estilos/estilo_CONTAto.css">

        <link rel="stylesheet" type="text/css" href="../estilos/atr_compras_css/pct_p_sTyle.css">
        <link rel="stylesheet" type="text/css" href="../estilos/atr_compras_css/CARRINho_compras.css"> 


        <meta name="viewport" content="width=device-width, initial-scale=1.0">



       <link rel="icone" href="../../imagens/favicon.ico" type="image/x-icon">
       <link rel="icon" href="../../imagens/favicon.ico" type="image/x-icon">
        



    </head>



<!--______________________________________________________________________________-->
<!--______________________________________________________________________________-->
<!--______________________________________________________________________________-->
<!--_______________________________CORPO_________________________________________________-->






<body id="cor_de_fundo">



  <div class="container"  id="cor_do_container" >

   <div align="center" id="roda_teto" class="rounded">
     <img src="../../imagens/logo_princ.png" id="img_logo">
   </div> 

   <hr>

            
<!--______________________________________________________________________________-->


<div class="row" >

  <div class="col-3" >
    <div id="abaixar_menus"  class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      

      <a class="nav-link <?php echo $menu_1_ativo ?>" href="index.php?acao=<?php echo $menu_1 ?>" role="tab" aria-controls="v-pills-home" aria-selected="true" ><h6>Home</h6></a>

      <a class="nav-link <?php echo $menu_2_ativo ?>" href="index.php?acao=<?php echo $menu_2 ?>" role="tab"aria-controls="v-pills-profile" aria-selected="false"><h6>Produtos</h6></a>

      <a class="nav-link <?php echo $menu_3_ativo ?>" href="index.php?acao=<?php echo $menu_3 ?>" role="tab"aria-controls="v-pills-messages" aria-selected="false"><h6>Contatos</h6></a>

      <a class="nav-link <?php echo $menu_4_ativo ?>" href="index.php?acao=<?php echo $menu_4?>" role="tab" aria-controls="v-pills-settings" aria-selected="false"><h6>Informações</h6></a>
      
    </div>
  </div>

   <hr>


              <div class="col-9" style="padding-left: 50px" >
                <div class="tab-content" id="v-pills-tabContent">
                 <div class="tab-pane fade show active"  role="tabpanel">

                  <?php                                                                                                                                                                       

                       if (@$_GET['acao'] == $menu_1 ) {   
                       include_once ($menu_1.".php");}

                       elseif (@$_GET['acao'] == $menu_2 or isset($_GET['$menu_2']) ) {
                       include_once ($menu_2.".php");}

                       elseif (@$_GET['acao'] == $menu_3) {
                       include_once ($menu_3.".php");}

                       elseif (@$_GET['acao'] == $menu_4) {
                       include_once ($menu_4.".php");}

                          else { 

                       include_once ($menu_1.".php");
                         }
                          ?> 

                        </div>
                      </div>
                    </div>


 </div>
<!--______________________________________________________________________________-->

           
<br>
<div align="center" style="padding: 15px;background:  #77CEFA;" class="jumbotron border" >

   <a href="https://www.facebook.com/tecnobabysaudearte/?ref=br_rs"> <img src="../../imagens/facebook.png" id="facebook" class="rounded-circle"style="padding: 15px ;"></a>
    <a href="https://www.mercadolivre.com.br/"><img src="../../imagens/ml.png" id="ml" class="rounded-circle"style="padding: 15px"></a>
    <a href="http://api.whatsapp.com/send?phone=5561992620397"><img src="../../imagens/zapzap.png" id="zapzap"style="padding: 15px"></a>
    <a href="https://www.instagram.com/tecnobabysaude.arte/"><img src="../../imagens/instagram.png" id="instagram_img"style="padding: 15px"></a>
    <a href="https://pagseguro.uol.com.br/#rmcl"><img src="../../imagens/pagseguro.png" id="pagseguro"style="padding: 15px"></a>

  </div>

 <hr>







<!--______________________________________________________________________________-->
<!--______________________________________________________________________________-->

 
<footer class="container">



 
    <br>

    <div align="center" id="roda_teto" class="rounded">
    
    <i>Todos os direitos reservados</i>
    nestertec@gmail.com
    <p>Ivan Rank</p>

    </div>


</footer>





 















<!--_______________FIM______________________-->
            </body>

</html>