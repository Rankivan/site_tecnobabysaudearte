 


 <?php



   if (isset($_POST['email_cadastro']) && !empty($_POST['email_cadastro'])) {
   	# code...
   

     $descricao_p = addslashes ($_POST['descricao_p']);
     $descricao_m = addslashes ($_POST['descricao_m']);
     $descricao_g = addslashes ($_POST['descricao_g']);
     $descricao_kit = addslashes ($_POST['descricao_kit']);
     $frete_output = addslashes ($_POST['frete_output']);




     $nome_cadastro         = addslashes ($_POST['nome_cadastro']);
     $email_cadastro        = addslashes ($_POST['email_cadastro']);
     $endereco_cadastro     = addslashes ($_POST['endereco_cadastro']);
     $cidade_cadastro       = addslashes ($_POST['cidade_cadastro']);
     $estado_cadastro       = addslashes ($_POST['estado_cadastro']);
     $cep_output_2          = addslashes ($_POST['cep_output_2']);
     $telefone_cadastro     = addslashes ($_POST['telefone_cadastro']);
     $cpf_cadastro          = addslashes ($_POST['cpf_cadastro']);

     
     $endereco = "contato@tecnobabysaudearte.com.br,tecnobabysaudeearte@gmail.com,ivanrank@yahoo.com.br";
     //
     $subjet = "Tecnobaby - Vendas com frete";


     $body =  "Nome:  ".$nome_cadastro."\n".
              "Email: ".$email_cadastro."\n".
              "Endereço: ".$endereco_cadastro."\n".
              "Cidade: ".$cidade_cadastro."\n".
              "Estado: ".$estado_cadastro."\n".
              "CEP: ".$cep_output_2."\n".
              "Telefone: ".$telefone_cadastro."\n".
              "CPF: ".$cpf_cadastro ."\n".


              $descricao_p."\n".
              $descricao_m."\n".
              $descricao_g."\n".
              $descricao_kit ."\n".
              $frete_output ;


     $header = "From:tecnobabysaudeearte@gmail.com"."\r\n"."Reply-To: ".$email_cadastro."\r\n"."X=mailer:PHP/".phpversion();

     if(mail($endereco,$subjet,$body)) 
     {

      
      echo ("Email Enviado com sucesso!");


     } else {




         echo ("Email Não enviado, falha na conexão!");





     }



}



   ?>