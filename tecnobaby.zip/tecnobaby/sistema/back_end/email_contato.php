

   <?php

   if (isset($_POST['email']) && !empty($_POST['email'])) {
   	# code...
   

     $nome = addslashes ($_POST['nome']);
     $email = addslashes ($_POST['email']);
     $mensagem = addslashes ($_POST['mensagem']);

     $endereco = "contato@tecnobabysaudearte.com.br,tecnobabysaudeearte@gmail.com,ivanrank@yahoo.com.br";
     $subjet = "tecnobaby - contato";

     $body =  "Nome: ".$nome."\n".
              "Email: ".$email."\n".
              "Mensagem: ".$mensagem;

     $header = "From:tecnobabysaudeearte@gmail.com"."\r\n"."Reply-To: ".$email."\r\n"."X=mailer:PHP/".phpversion();

     if(mail($endereco,$subjet,$body)) 
     {

      
      echo ("Email Enviado com sucesso!");


     } else {




         echo ("Email Não enviado, falha na conexão!");





     }



}



   ?>