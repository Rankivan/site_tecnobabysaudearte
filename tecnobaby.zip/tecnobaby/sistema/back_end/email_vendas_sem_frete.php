

<?php



   if (isset($_POST['email_cadastro_2']) && !empty($_POST['email_cadastro_2'])) {
   	# code...
   

     $descricao_p_2    = addslashes ($_POST['descricao_p_2']);
     $descricao_m_2    = addslashes ($_POST['descricao_m_2']);
     $descricao_g_2    = addslashes ($_POST['descricao_g_2']);
     $descricao_kit_2  = addslashes ($_POST['descricao_kit_2']);
     




     $nome_cadastro_2      = addslashes ($_POST['nome_cadastro_2']);
     $telefone_cadastro_2  = addslashes ($_POST['telefone_cadastro_2']);
     $email_cadastro_2     = addslashes ($_POST['email_cadastro_2']);
     $cpf_cadastro_2       = addslashes ($_POST['cpf_cadastro_2']);

     
     $endereco = "contato@tecnobabysaudearte.com.br,tecnobabysaudeearte@gmail.com,ivanrank@yahoo.com.br";
     //
     $subjet = "Tecnobaby - Vendas SEM frete";


     $body =  "Nome:  ".$nome_cadastro_2."\n".
              "Email: ".$email_cadastro_2."\n".
              "Telefone: ".$telefone_cadastro_2."\n".
              "CPF: ".$cpf_cadastro_2 ."\n".


              $descricao_p_2."\n".
              $descricao_m_2."\n".
              $descricao_g_2."\n".
              $descricao_kit_2 ."\n".
              "Opção SEM frete";


    $header = "From:tecnobabysaudeearte@gmail.com"."\r\n"."Reply-To: ".$email_cadastro."\r\n"."X=mailer:PHP/".phpversion();

     if(mail($endereco,$subjet,$body)) 
     {

      
      echo ("Email Enviado com sucesso!");


     } else {




         echo ("Email Não enviado, falha na conexão!");





     }



}



   ?>