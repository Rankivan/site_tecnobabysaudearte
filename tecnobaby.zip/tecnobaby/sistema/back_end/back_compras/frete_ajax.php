

<?php 

 
  $cep_destino = ($_POST['cep_destino']);



   

    function calcular_frete(
    	$cep_origem,
    	$cep_destino,
    	$peso,
    	$valor,
    	$tipo_do_frete,
    	$altura = 8,
    	$largura=25,
        $comprimento = 25)

    {

    	$url = "http://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx?";

        $url .= "nCdEmpresa=";
        $url .= "&sDsSenha=";
        $url .= "&sCepOrigem=". $cep_origem;
        $url .= "&sCepDestino=". $cep_destino;
        $url .= "&nVlPeso=". $peso;
        $url .= "&nVlLargura=". $largura;
        $url .= "&nVlAltura=". $altura;
        $url .= "&nVlComprimento=". $comprimento;
        $url .= "&nCdFormato=1";
        $url .= "&sCdMaoPropria=n";
        $url .= "&nVlValorDeclarado=". $valor;
        $url .= "&sCdAvisoRecebimento=n";
        $url .= "&nCdServico=".$tipo_do_frete;
        $url .= "&nVlDiametro=0";
        $url .= "&StrRetorno=xml";

        

 
        $xml = simplexml_load_file($url);

        return $xml->cServico;  

    }

    $val = (calcular_frete(
    
        '77410010',
    	$cep_destino,
    	2,
    	0,
    	'41106'
    	));

   
   

     
    $valor_frete =  $val->Valor;

    echo $valor_frete ;

    

    

    



 