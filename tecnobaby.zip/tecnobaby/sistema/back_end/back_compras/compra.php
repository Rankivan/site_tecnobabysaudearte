

<?php

   

   $valor_1 = ($_POST['valor_1']);
  
  

   $data ['token'] = '5b9ed178-dfbb-4375-96e7-01bcc5b3dcd9eb03475040a48aca1a3e7730e749d30730ff-f6a0-424b-9c79-227f1d82de13' ;
   $data ['email'] ='ivanrank@yahoo.com.br';
   $data ['currency'] = 'BRL' ;
   $data ['itemId1'] = '1' ;
   $data ['itemQuantity1'] = '1' ;
   $data ['itemDescription1'] = 'Compra_TecnobabySaude&arte';
   $data ['itemAmount1'] = $valor_1;

   $url = 'https://ws.pagseguro.uol.com.br/v2/checkout';

   $data = http_build_query($data);

   $curl = curl_init($url);


  curl_setopt ($curl,CURLOPT_RETURNTRANSFER, true);
  curl_setopt ($curl,CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt ($curl,CURLOPT_POST,true);
	curl_setopt ($curl,CURLOPT_POSTFIELDS,$data);
	curl_setopt ($curl,CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);

	$xml = curl_exec($curl);
	curl_close($curl);

	$xml = simplexml_load_string($xml);
	$codigo = $xml -> code;

  echo $codigo;

  ?>



