 


 function loadfrete(){


  

    var cep_destino = $('#cep_destino').val();

 
    var cep_invalido_boolean = 1;

    document.getElementById('cep_invalido_boolean').value = cep_invalido_boolean;
    

  



    $.ajax({

     url:'../back_end/back_compras/frete_ajax.php',
     type:'POST',
     dataType:'html',
     cache:false,
     data: {cep_destino: cep_destino},

     success: function(data){

     	console.log('valor = ' + data);


    //https://tecnobabysaudearte.com.br/tecnobaby/sistema/back_end/back_compras/frete_ajax.php'
       

    

      var sucess = 'Frete adicionado ao seu carrinho de compras, clique em "continuar".';
    
      $('#sucess').val(sucess);






      //_______________________________________________

     	$('#valor_frete_1').val(data);
      $('#valor_frete_2').val(data);
      $('#valor_frete_3').val(data);
      $('#valor_frete_4').val(data);
      $('#valor_frete_5').val(data);




     },beforeSend: function(){


     },error: function (jqXHR,textStatus,errorThrown){
     	console.log('Erro');
     } });



}