

// Funcao da modal

    	$(document).ready(function(){

    		$(exampleModal).modal('show');


    	});


    	$(document).ready(function(){  /* MASCARA para os telefones e cpfs*/
       
       
       $('#cep_destino').mask ('00000000'); 
   

   });





