


$("#div_prod_pct_p").hide(); 
$("#div_prod_pct_m").hide(); 
$("#div_prod_pct_g").hide(); 
$("#div_prod_pct_kit").hide();

 $("#recalcular_valor_qtd").hide(); 




    

  //PRODUTOS
  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++PACOTIONHO P+++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

      function adicionar_p(){


            var qtd_p_add = document.getElementById('qtd_prod_pct_p').value;

            if (qtd_p_add < 5) {  

              qtd_p_add = parseFloat(qtd_p_add);
              soma_qtd_p = qtd_p_add + 1;

              document.getElementById('qtd_prod_pct_p').value = soma_qtd_p;

               $("#recalcular_valor_qtd").show();
               $("#btn_finalizar_compra_2").hide();
            }

               
          }

          function diminuir_p(){

            var qtd_p_add = document.getElementById('qtd_prod_pct_p').value;

            if (qtd_p_add > 1) {

              qtd_p_add = parseFloat(qtd_p_add);
              soma_qtd_p = qtd_p_add - 1;

              document.getElementById('qtd_prod_pct_p').value = soma_qtd_p;

               $("#recalcular_valor_qtd").show();
               $("#btn_finalizar_compra_2").hide();
            }

          }


  
  function pord_pct_p (){



  
    
  	  
     var   qtd_prod_pct_p = document.getElementById('qtd_prod_pct_p').value;
     
     var valor_prod_pct_p = 250*(qtd_prod_pct_p);

//_____________________________________

    if ( qtd_prod_pct_p > 0 ) {

     var       peso_pct_p = 1;
     var   dimensao_pct_p = 1;

    } else{


     var       peso_pct_p = 0;
     var   dimensao_pct_p = 0;

   


    }

//_____________________________________




  

   document.getElementById('valor_prod_pct_p').value         = valor_prod_pct_p;
   document.getElementById('qtd_prod_pct_p_output').value    = qtd_prod_pct_p;
   document.getElementById('peso_pct_p').value               =  peso_pct_p;
   document.getElementById('dimensao_pct_p').value           = dimensao_pct_p;



    $("#div_prod_pct_p").show();




    var descricao_p = qtd_prod_pct_p+'x - '+'Pacotinho P = R$ 250,00';
    document.getElementById('descricao_p').value = descricao_p; 
    document.getElementById('descricao_p_2').value = descricao_p;


 


}

//______________________________EXCLUI________________________________________


 function excluir_pord_pct_p (){


  	 var valor_prod_pct_p = 0;
     var   qtd_prod_pct_p = 0;
     var       peso_pct_p = 0;
     var   dimensao_pct_p = 0;

  

   document.getElementById('valor_prod_pct_p').value       = valor_prod_pct_p;
   document.getElementById('qtd_prod_pct_p_output').value  = qtd_prod_pct_p;
   document.getElementById('peso_pct_p').value             =  peso_pct_p;
   document.getElementById('dimensao_pct_p').value         = dimensao_pct_p;


   $("#div_prod_pct_p").hide(); 



   var descricao_p = '';
   document.getElementById('descricao_p').value = descricao_p; 
  document.getElementById('descricao_p_2').value = descricao_p;

 



 	}




//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++PACOTIONHO M+++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

      function adicionar_m(){


            var qtd_m_add = document.getElementById('qtd_prod_pct_m').value;

            if (qtd_m_add < 5) {  

              qtd_m_add = parseFloat(qtd_m_add);
              soma_qtd_m = qtd_m_add + 1;

              document.getElementById('qtd_prod_pct_m').value = soma_qtd_m;

               $("#recalcular_valor_qtd").show();
               $("#btn_finalizar_compra_2").hide();
            }

               
          }

          function diminuir_m(){

            var qtd_m_add = document.getElementById('qtd_prod_pct_m').value;

            if (qtd_m_add > 1) {

              qtd_m_add = parseFloat(qtd_m_add);
              soma_qtd_m = qtd_m_add - 1;

              document.getElementById('qtd_prod_pct_m').value = soma_qtd_m;

               $("#recalcular_valor_qtd").show();
               $("#btn_finalizar_compra_2").hide();
            }

          }




  function pord_pct_m (){


  	 
     var   qtd_prod_pct_m = document.getElementById('qtd_prod_pct_m').value;
     var       peso_pct_m = 1;
     var   dimensao_pct_m = 1;
     var valor_prod_pct_m = 270*(qtd_prod_pct_m);


     //_____________________________________

		    if ( qtd_prod_pct_m > 0 ) {

		     var       peso_pct_m = 1;
		     var   dimensao_pct_m = 1;

		    } else{


		     var       peso_pct_m = 0;
		     var   dimensao_pct_m = 0;



		    }

   //_____________________________________


   

   document.getElementById('valor_prod_pct_m').value         = valor_prod_pct_m;
   document.getElementById('qtd_prod_pct_m_output').value    = qtd_prod_pct_m;
   document.getElementById('peso_pct_m').value               =  peso_pct_m;
   document.getElementById('dimensao_pct_m').value           = dimensao_pct_m;


 $("#div_prod_pct_m").show();


   var descricao_m = qtd_prod_pct_m+'x - '+'Pacotinho m = R$ 270,00';
    document.getElementById('descricao_m').value = descricao_m; 
   document.getElementById('descricao_m_2').value = descricao_m; 


}

//_________________________________EXCLUI_____________________________________



function excluir_pord_pct_m (){



	 var valor_prod_pct_m = 0;
     var   qtd_prod_pct_m = 0;
     var       peso_pct_m = 0;
     var   dimensao_pct_m = 0;


   

   document.getElementById('valor_prod_pct_m').value         = valor_prod_pct_m;
   document.getElementById('qtd_prod_pct_m_output').value    = qtd_prod_pct_m;
   document.getElementById('peso_pct_m').value               =  peso_pct_m;
   document.getElementById('dimensao_pct_m').value           = dimensao_pct_m;



   $("#div_prod_pct_m").hide();  

   var descricao_m= '';
   document.getElementById('descricao_m').value = descricao_m;
  document.getElementById('descricao_m_2').value = descricao_m; 

	}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++PACOTIONHO G+++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

      function adicionar_g(){


            var qtd_g_add = document.getElementById('qtd_prod_pct_g').value;

            if (qtd_g_add < 5) {  

              qtd_g_add = parseFloat(qtd_g_add);
              soma_qtd_g = qtd_g_add + 1;

              document.getElementById('qtd_prod_pct_g').value = soma_qtd_g;

               $("#recalcular_valor_qtd").show();
               $("#btn_finalizar_compra_2").hide();
            }

               
          }

          function diminuir_g(){

            var qtd_g_add = document.getElementById('qtd_prod_pct_g').value;

            if (qtd_g_add > 1) {

              qtd_g_add = parseFloat(qtd_g_add);
              soma_qtd_g = qtd_g_add - 1;

              document.getElementById('qtd_prod_pct_g').value = soma_qtd_g;

               $("#recalcular_valor_qtd").show();
               $("#btn_finalizar_compra_2").hide();
            }

          }

  function pord_pct_g (){


     
     var   qtd_prod_pct_g = document.getElementById('qtd_prod_pct_g').value;
     var       peso_pct_g = 1;
     var   dimensao_pct_g = 1;
     var valor_prod_pct_g = 290*(qtd_prod_pct_g);


     //_____________________________________

        if ( qtd_prod_pct_g > 0 ) {

         var       peso_pct_g = 1;
         var   dimensao_pct_g = 1;

        } else{


         var       peso_pct_g = 0;
         var   dimensao_pct_g = 0;



        }

   //_____________________________________


   

   document.getElementById('valor_prod_pct_g').value         = valor_prod_pct_g;
   document.getElementById('qtd_prod_pct_g_output').value    = qtd_prod_pct_g;
   document.getElementById('peso_pct_g').value               =  peso_pct_g;
   document.getElementById('dimensao_pct_g').value           = dimensao_pct_g;


 $("#div_prod_pct_g").show();

 var descricao_g = qtd_prod_pct_g+'x - '+'Pacotinho g = R$ 290,00';
    document.getElementById('descricao_g').value = descricao_g; 
    document.getElementById('descricao_g_2').value = descricao_g;
   


}

//_________________________________EXCLUI_____________________________________



function excluir_pord_pct_g (){



     var valor_prod_pct_g = 0;
     var   qtd_prod_pct_g = 0;
     var       peso_pct_g = 0;
     var   dimensao_pct_g = 0;


   

   document.getElementById('valor_prod_pct_g').value         = valor_prod_pct_g;
   document.getElementById('qtd_prod_pct_g_output').value    = qtd_prod_pct_g;
   document.getElementById('peso_pct_g').value               =  peso_pct_g;
   document.getElementById('dimensao_pct_g').value           = dimensao_pct_g;



   $("#div_prod_pct_g").hide();  


    var descricao_g= '';
   document.getElementById('descricao_g').value = descricao_g;
   document.getElementById('descricao_g_2').value = descricao_g;
   
  

  }




//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++PACOTIONHO KIT+++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
          function adicionar_kit(){


            var qtd_kit_add = document.getElementById('qtd_prod_pct_kit').value;

            if (qtd_kit_add < 5) {  

              qtd_kit_add = parseFloat(qtd_kit_add);
              soma_qtd_kit = qtd_kit_add + 1;

              document.getElementById('qtd_prod_pct_kit').value = soma_qtd_kit;

               $("#recalcular_valor_qtd").show();
               $("#btn_finalizar_compra_2").hide();
            }

               
          }

          function diminuir_kit(){

            var qtd_kit_add = document.getElementById('qtd_prod_pct_kit').value;

            if (qtd_kit_add > 1) {

              qtd_kit_add = parseFloat(qtd_kit_add);
              soma_qtd_kit = qtd_kit_add - 1;

              document.getElementById('qtd_prod_pct_kit').value = soma_qtd_kit;

               $("#recalcular_valor_qtd").show();
               $("#btn_finalizar_compra_2").hide();
            }

          }

  function pord_pct_kit (){


     
     var   qtd_prod_pct_kit = document.getElementById('qtd_prod_pct_kit').value;
     var       peso_pct_kit = 1;
     var   dimensao_pct_kit = 1;
     var valor_prod_pct_kit = 650*(qtd_prod_pct_kit);


     //_____________________________________

        if ( qtd_prod_pct_kit > 0 ) {

         var       peso_pct_kit = 1;
         var   dimensao_pct_kit = 1;

        } else{


         var       peso_pct_kit = 0;
         var   dimensao_pct_kit = 0;

        }

   //_____________________________________


   

   document.getElementById('valor_prod_pct_kit').value         = valor_prod_pct_kit;
   document.getElementById('qtd_prod_pct_kit_output').value    = qtd_prod_pct_kit;
   document.getElementById('peso_pct_kit').value               =  peso_pct_kit;
   document.getElementById('dimensao_pct_kit').value           = dimensao_pct_kit;

   //#######################################


 $("#div_prod_pct_kit").show();

     var descricao_kit = qtd_prod_pct_kit+'x - '+'Pacotinho kit = R$ 650,00';
     document.getElementById('descricao_kit').value = descricao_kit; 
     document.getElementById('descricao_kit_2').value = descricao_kit; 
   
}

//_________________________________EXCLUI_____________________________________



function excluir_pord_pct_kit (){

     var valor_prod_pct_kit = 0;
     var   qtd_prod_pct_kit = 0;
     var       peso_pct_kit = 0;
     var   dimensao_pct_kit = 0;


  
   document.getElementById('valor_prod_pct_kit').value         = valor_prod_pct_kit;
   document.getElementById('qtd_prod_pct_kit_output').value    = qtd_prod_pct_kit;
   document.getElementById('peso_pct_kit').value               =  peso_pct_kit;
   document.getElementById('dimensao_pct_kit').value           = dimensao_pct_kit;



   $("#div_prod_pct_kit").hide();  


   var descricao_kit= '';
   document.getElementById('descricao_kit').value = descricao_kit;
   document.getElementById('descricao_kit_2').value = descricao_kit; 
  

  }


  function atualizar_valores(){

      $("#btn_finalizar_compra_2").show();
      $("#recalcular_valor_qtd").hide();




  }












//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^




