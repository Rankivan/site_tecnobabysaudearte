   


        window.load = slide_g(1);

        var background_number_g = 1;


        function slide_g(n){

        	var all_backgrouds = 3;

            //Carregamento de imagem via JS

			 document.getElementById("img_slide_g").src = "../../imagens/tec_img/slide_g/"+n+".jpg";

			}; //Modificação no link http://localhost/sistemas | https://tecnobabysaudearte.com.br/tecnobaby/


 function anterior_g (){

 	if (background_number_g>1) {

 		background_number_g--;

 		slide_g(background_number_g);

 	}

 	}


function proximo_g (){

 	if (background_number_g<5) {

 		background_number_g++;

 		slide_g(background_number_g);
 	}}