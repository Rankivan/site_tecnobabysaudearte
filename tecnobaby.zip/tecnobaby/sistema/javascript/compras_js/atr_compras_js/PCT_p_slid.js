
        
        window.load = slide_p(1);

        var background_number_p = 1;


        function slide_p (n){

        	var all_backgrouds = 3;

            //Carregamento de imagem via JS

			 document.getElementById("img_slide_p").src = "../../imagens/tec_img/slide_p/"+n+".jpg";

			};//Modificação no link http://localhost/sistemas | https://tecnobabysaudearte.com.br/tecnobaby/


 function anterior_p (){

 	if (background_number_p >1) {

 		background_number_p --;

 		slide_p(background_number_p );

 	}

 	}


function proximo_p (){

 	if (background_number_p <5) {

 		background_number_p ++;

 		slide_p(background_number_p);


 	}

 	}