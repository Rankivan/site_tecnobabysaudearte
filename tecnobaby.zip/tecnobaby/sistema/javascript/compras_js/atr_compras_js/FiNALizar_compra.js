


function finalizar_compra(){

      $.post("../back_end/back_compras/compra.php",'', function(data) {
        
        $('#code').val();
        $('#comprar').submit();

        } )
    }  



    function cadastro(){


      $("#frete_calculado").show();
      $("#frete_calculado_2").show();


       $("#btn_cadastro").hide();
       $("#cadastro").hide();




    }


 function enviar(){


  var frete_invalido  = document.getElementById('exibir_msg_frete_invalido').value;


       





      if (frete_invalido == 0) {


       $("#frete_calculado").hide();
       $("#frete_calculado_2").hide();
       $("#frete_calculado_3").hide();

       $("#frete_nao_calculado").show();
       $("#frete_nao_calculado_2").show();
       $("#frete_nao_calculado_3").show();


        $("#cadastro").hide();
        $("#btn_cadastro").hide();

      

      } else{




       $("#frete_calculado").hide();
       $("#frete_calculado_2").hide();
       $("#frete_calculado_3").show();

       $("#frete_nao_calculado").hide();
       $("#frete_nao_calculado_2").hide();
       $("#frete_nao_calculado_3").hide();


       $("#btn_cadastro").show();
       $("#cadastro").show();




      }


  

    var valor_1 = $('#total_final_3').val();

    

    $.ajax({

     url:'../back_end/back_compras/compra.php',
     type:'POST',
     dataType:'html',
     data: {valor_1: valor_1},

     success: function(data){

    
     $('#code').val(data);




     },beforeSend: function(){


     },error: function (jqXHR,textStatus,errorThrown){
      console.log('Erro');
     } });



}













/*

   $('#form1').submit(function(e){

   	e.preventDefault();


   	var Valor_1 = $('#total_final_3').val();

   	console.log(valor);

   	$.ajax({

   		url: 'http://localhost/sistemas/tecnobaby/sistema/telas/atr_compras/carrinho_de_compras.php',
   		method: 'POST',
   		data:{Valor_1: Valor_1},
   		dataType:'html',

   	}).done(function(result){

 


    
   	});

});*/

