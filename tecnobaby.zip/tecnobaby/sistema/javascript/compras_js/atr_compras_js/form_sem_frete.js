





function cadastra_form_2(){

	



			    var descricao_p_2   = $('#descricao_p_2').val();
			    var descricao_m_2   = $('#descricao_m_2').val();
			    var descricao_g_2   = $('#descricao_g_2').val();
			    var descricao_kit_2 = $('#descricao_kit_2').val();
			    

			    var nome_cadastro_2          = $('#nome_cadastro_2').val();
			    var telefone_cadastro_2      = $('#telefone_cadastro_2').val();
			    var cpf_cadastro_2           = $('#cpf_cadastro_2').val();
			    var email_cadastro_2         = $('#email_cadastro_2').val();



			    $.ajax({

			     url:'../back_end/email_vendas_sem_frete.php',
			     type:'POST',
			     method:'POST',
			     dataType:'html',
			     cache:false,
			     data: { 
			       descricao_p_2 : descricao_p_2,
			       descricao_m_2 : descricao_m_2,
			       descricao_g_2: descricao_g_2,
			       descricao_kit_2: descricao_kit_2,

			       nome_cadastro_2: nome_cadastro_2,
			       telefone_cadastro_2: telefone_cadastro_2,
			       cpf_cadastro_2: cpf_cadastro_2,
			       email_cadastro_2: email_cadastro_2},

			     success: function(data){

			     	alert('"Sem frete" enviado com sucesso');


			      

			     	

			     },beforeSend: function(){


			     },error: function (jqXHR,textStatus,errorThrown){
			     	console.log('Erro');


			        alert('erro no envio');

			     } });

   



      }