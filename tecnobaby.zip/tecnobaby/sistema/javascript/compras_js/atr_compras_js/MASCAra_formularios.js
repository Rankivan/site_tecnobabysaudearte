
     $("#msg_campo_vazio").show(); 
     $("#btn_enviar_cadastro_2").hide();
     $("#btn_enviar_cadastro_1").hide();

     $("#msg_email_2").show(); 
     $("#msg_email_1").show(); 


       

    var frete = document.getElementById("exibir_msg_frete_invalido").value;






   function letra_nome(nome_completo){  /* LETRAS MAIUSCULAS DO NOME*/ 

      var nome_completo = document.getElementById("nome_cadastro").value;

      nome_completo = nome_completo.toLowerCase().replace(/(?:^|\s)\S/g, function(capitalize) { return capitalize.toUpperCase(); });

      var PreposM = ["Da","Do","Das","Dos","A", "E"];
      var prepos = ["da","do","das","dos","a", "e"];

      for (var i = PreposM.length - 1; i >= 0; i--) {
        nome_completo = nome_completo.replace(RegExp("\\b" + PreposM[i].replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&') + "\\b", "g"), prepos[i]);
      }

      document.getElementById("nome_cadastro").value = nome_completo;

                          
                          var nome_completo = document.getElementById("nome_cadastro").value;
                          var cpf = document.getElementById("cpf_cadastro").value;
                          var letra_endereco = document.getElementById("endereco_cadastro").value;
                          var letra_cidade = document.getElementById("cidade_cadastro").value;
                          var letra_estado = document.getElementById("estado_cadastro").value;
                          var telefone_contato = document.getElementById("telefone_cadastro").value;
                          var email_contato = document.getElementById("email_cadastro").value;



                          if ((nome_completo && cpf && letra_endereco && letra_cidade && letra_estado && telefone_contato && email_contato ) != '') {
                           var soma_1 = 1;
                           document.getElementById("soma_1").value = soma_1;
                           $("#msg_email_1").hide();

                          }

                          if (soma_1 == 1) {

                            $("#btn_enviar_cadastro_1").show(); 
                            $("#msg_campo_vazio_1").hide(); 
                         }
                              if (soma_1 != 1) {

                            $("#btn_enviar_cadastro_1").hide(); 
                            $("#msg_campo_vazio_1").show(); 

                          }


    } 






      function cpf(cpf_contato){  /* LETRAS MAIUSCULAS DO NOME*/ 

      var cpf = document.getElementById("cpf_cadastro").value;

      cpf = cpf.toLowerCase().replace(/(?:^|\s)\S/g, function(capitalize) { return capitalize.toUpperCase(); });

   

      document.getElementById("cpf_cadastro").value = cpf; 






                          var nome_completo = document.getElementById("nome_cadastro").value;
                          var cpf = document.getElementById("cpf_cadastro").value;
                          var letra_endereco = document.getElementById("endereco_cadastro").value;
                          var letra_cidade = document.getElementById("cidade_cadastro").value;
                          var letra_estado = document.getElementById("estado_cadastro").value;
                          var telefone_contato = document.getElementById("telefone_cadastro").value;
                          var email_contato = document.getElementById("email_cadastro").value;



                          if ((nome_completo && cpf && letra_endereco && letra_cidade && letra_estado && telefone_contato && email_contato ) != '') {
                           var soma_1 = 1;
                           document.getElementById("soma_1").value = soma_1;
                           $("#msg_email_1").hide();

                          }

                          if (soma_1 == 1) {

                            $("#btn_enviar_cadastro_1").show(); 
                            $("#msg_campo_vazio_1").hide(); 
                         }
                              if (soma_1 != 1) {

                            $("#btn_enviar_cadastro_1").hide(); 
                            $("#msg_campo_vazio_1").show(); 

                          }     

      

    }





			


     function letra_endereco(endereco){  /* LETRAS MAIUSCULAS DO NOME*/

      var letra_endereco = document.getElementById("endereco_cadastro").value;

      letra_endereco = letra_endereco.toLowerCase().replace(/(?:^|\s)\S/g, function(capitalize) { return capitalize.toUpperCase(); });

      var PreposM = ["Da","Do","Das","Dos","A", "E"];
      var prepos = ["da","do","das","dos","a", "e"];

      for (var i = PreposM.length - 1; i >= 0; i--) {
        letra_endereco = letra_endereco.replace(RegExp("\\b" + PreposM[i].replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&') + "\\b", "g"), prepos[i]);
      }

      document.getElementById("endereco_cadastro").value = letra_endereco;

     
                          var nome_completo = document.getElementById("nome_cadastro").value;
                          var cpf = document.getElementById("cpf_cadastro").value;
                          var letra_endereco = document.getElementById("endereco_cadastro").value;
                          var letra_cidade = document.getElementById("cidade_cadastro").value;
                          var letra_estado = document.getElementById("estado_cadastro").value;
                          var telefone_contato = document.getElementById("telefone_cadastro").value;
                          var email_contato = document.getElementById("email_cadastro").value;



                          if ((nome_completo && cpf && letra_endereco && letra_cidade && letra_estado && telefone_contato && email_contato ) != '') {
                           var soma_1 = 1;
                           document.getElementById("soma_1").value = soma_1;
                           $("#msg_email_1").hide();

                          }

                          if (soma_1 == 1) {

                            $("#btn_enviar_cadastro_1").show(); 
                            $("#msg_campo_vazio_1").hide(); 
                         }
                              if (soma_1 != 1) {

                            $("#btn_enviar_cadastro_1").hide(); 
                            $("#msg_campo_vazio_1").show(); 

                          } 

    }



     function letra_cidade(cidade){  /* LETRAS MAIUSCULAS DO NOME*/

      var letra_cidade = document.getElementById("cidade_cadastro").value;

      letra_cidade = letra_cidade.toLowerCase().replace(/(?:^|\s)\S/g, function(capitalize) { return capitalize.toUpperCase(); });

      var PreposM = ["Da","Do","Das","Dos","A", "E"];
      var prepos = ["da","do","das","dos","a", "e"];

      for (var i = PreposM.length - 1; i >= 0; i--) {
        letra_cidade = letra_cidade.replace(RegExp("\\b" + PreposM[i].replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&') + "\\b", "g"), prepos[i]);
      }

      document.getElementById("cidade_cadastro").value = letra_cidade;

      
                           var nome_completo = document.getElementById("nome_cadastro").value;
                          var cpf = document.getElementById("cpf_cadastro").value;
                          var letra_endereco = document.getElementById("endereco_cadastro").value;
                          var letra_cidade = document.getElementById("cidade_cadastro").value;
                          var letra_estado = document.getElementById("estado_cadastro").value;
                          var telefone_contato = document.getElementById("telefone_cadastro").value;
                          var email_contato = document.getElementById("email_cadastro").value;



                          if ((nome_completo && cpf && letra_endereco && letra_cidade && letra_estado && telefone_contato && email_contato ) != '') {
                           var soma_1 = 1;
                           document.getElementById("soma_1").value = soma_1;
                           $("#msg_email_1").hide();

                          }

                          if (soma_1 == 1) {

                            $("#btn_enviar_cadastro_1").show(); 
                            $("#msg_campo_vazio_1").hide(); 
                         }
                              if (soma_1 != 1) {

                            $("#btn_enviar_cadastro_1").hide(); 
                            $("#msg_campo_vazio_1").show(); 

                          }

    }



        function letra_estado(estado){  /* LETRAS MAIUSCULAS DO NOME*/

      var letra_estado = document.getElementById("estado_cadastro").value;

      letra_estado = letra_estado.toLowerCase().replace(/(?:^|\s)\S/g, function(capitalize) { return capitalize.toUpperCase(); });

      var PreposM = ["Da","Do","Das","Dos","A", "E"];
      var prepos = ["da","do","das","dos","a", "e"];

      for (var i = PreposM.length - 1; i >= 0; i--) {
        letra_estado = letra_estado.replace(RegExp("\\b" + PreposM[i].replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&') + "\\b", "g"), prepos[i]);
      }

      document.getElementById("estado_cadastro").value = letra_estado;




                          var nome_completo = document.getElementById("nome_cadastro").value;
                          var cpf = document.getElementById("cpf_cadastro").value;
                          var letra_endereco = document.getElementById("endereco_cadastro").value;
                          var letra_cidade = document.getElementById("cidade_cadastro").value;
                          var letra_estado = document.getElementById("estado_cadastro").value;
                          var telefone_contato = document.getElementById("telefone_cadastro").value;
                          var email_contato = document.getElementById("email_cadastro").value;



                          if ((nome_completo && cpf && letra_endereco && letra_cidade && letra_estado && telefone_contato && email_contato ) != '') {
                           var soma_1 = 1;
                           document.getElementById("soma_1").value = soma_1;
                           $("#msg_email_1").hide();

                          }

                          if (soma_1 == 1) {

                            $("#btn_enviar_cadastro_1").show(); 
                            $("#msg_campo_vazio_1").hide(); 
                         }
                              if (soma_1 != 1) {

                            $("#btn_enviar_cadastro_1").hide(); 
                            $("#msg_campo_vazio_1").show(); 

                          }  
      
    }


          function telefone_contato(telefone){  /* LETRAS MAIUSCULAS DO NOME*/ 

      var telefone_contato = document.getElementById("telefone_cadastro").value;

      telefone_contato = telefone_contato.toLowerCase().replace(/(?:^|\s)\S/g, function(capitalize) { return capitalize.toUpperCase(); });

   

      document.getElementById("telefone_cadastro").value = telefone_contato; 



                          var nome_completo = document.getElementById("nome_cadastro").value;
                          var cpf = document.getElementById("cpf_cadastro").value;
                          var letra_endereco = document.getElementById("endereco_cadastro").value;
                          var letra_cidade = document.getElementById("cidade_cadastro").value;
                          var letra_estado = document.getElementById("estado_cadastro").value;
                          var telefone_contato = document.getElementById("telefone_cadastro").value;
                          var email_contato = document.getElementById("email_cadastro").value;



                          if ((nome_completo && cpf && letra_endereco && letra_cidade && letra_estado && telefone_contato && email_contato ) != '') {
                           var soma_1 = 1;
                           document.getElementById("soma_1").value = soma_1;
                           $("#msg_email_1").hide();

                          }

                          if (soma_1 == 1) {

                            $("#btn_enviar_cadastro_1").show(); 
                            $("#msg_campo_vazio_1").hide(); 
                         }
                              if (soma_1 != 1) {

                            $("#btn_enviar_cadastro_1").hide(); 
                            $("#msg_campo_vazio_1").show(); 

                          }       

    }



              function email_contato(email){  /* LETRAS MAIUSCULAS DO NOME*/ 

      var email_contato = document.getElementById("email_cadastro").value;

      document.getElementById("email_cadastro").value = email_contato; 



                          var nome_completo = document.getElementById("nome_cadastro").value;
                          var cpf = document.getElementById("cpf_cadastro").value;
                          var letra_endereco = document.getElementById("endereco_cadastro").value;
                          var letra_cidade = document.getElementById("cidade_cadastro").value;
                          var letra_estado = document.getElementById("estado_cadastro").value;
                          var telefone_contato = document.getElementById("telefone_cadastro").value;
                          var email_contato = document.getElementById("email_cadastro").value;



                          if ((nome_completo && cpf && letra_endereco && letra_cidade && letra_estado && telefone_contato && email_contato ) != '') {
                           var soma_1 = 1;
                           document.getElementById("soma_1").value = soma_1;
                           $("#msg_email_1").hide();

                          }

                          if (soma_1 == 1) {

                            $("#btn_enviar_cadastro_1").show(); 
                            $("#msg_campo_vazio_1").hide(); 
                         }
                              if (soma_1 != 1) {

                            $("#btn_enviar_cadastro_1").hide(); 
                            $("#msg_campo_vazio_1").show(); 

                          }
           
    }

    //_____________________________________________________________________________



    //_____________________________________________________________________________





 function letra_nome_2(nome_completo_2){  /* LETRAS MAIUSCULAS DO NOME*/ 

      var nome_completo_2 = document.getElementById("nome_cadastro_2").value;

      nome_completo_2 = nome_completo_2.toLowerCase().replace(/(?:^|\s)\S/g, function(capitalize) { return capitalize.toUpperCase(); });

      var PreposM = ["Da","Do","Das","Dos","A", "E"];
      var prepos = ["da","do","das","dos","a", "e"];

      for (var i = PreposM.length - 1; i >= 0; i--) {
        nome_completo_2 = nome_completo_2.replace(RegExp("\\b" + PreposM[i].replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&') + "\\b", "g"), prepos[i]);
      }

      document.getElementById("nome_cadastro_2").value = nome_completo_2;  

      
     //|||||||||||||||||||||||||||||   |||||||||||||||||||   ||||||||||||||||||||||||||  |||||||


                          var cpf_contato_2 = document.getElementById("cpf_cadastro_2").value;
                          var telefone_2 = document.getElementById("telefone_cadastro_2").value;
                          var email_2 = document.getElementById("email_cadastro_2").value;


                          if ((nome_completo_2 && cpf_contato_2 && telefone_2 && email_2 ) != '') {
                           var soma_2 = 1;
                           document.getElementById("soma_2").value = soma_2;
                           $("#msg_email_2").hide();

                          } else {
                                        var soma_2 = 0;
                                       document.getElementById("soma_2").value = soma_2;
                                      }

                          if (soma_2 == 1) {
                            $("#btn_enviar_cadastro_2").show(); 
                            $("#msg_campo_vazio").hide(); 
                         }
                              if (soma_2 != 1) {
                            $("#btn_enviar_cadastro_2").hide(); 
                            $("#msg_campo_vazio").show(); 

                          }







  } 




     function cpf_2(cpf_contato_2){  /* LETRAS MAIUSCULAS DO NOME*/ 

      var cpf_contato_2 = document.getElementById("cpf_cadastro_2").value;

      cpf_contato_2 = cpf_contato_2.toLowerCase().replace(/(?:^|\s)\S/g, function(capitalize) { return capitalize.toUpperCase(); });

   

      document.getElementById("cpf_cadastro_2").value = cpf_contato_2; 


   //|||||||||||||||||||||||||||||   |||||||||||||||||||   ||||||||||||||||||||||||||  |||||||


                        var nome_completo_2 = document.getElementById("nome_cadastro_2").value;
                        var telefone_2 = document.getElementById("telefone_cadastro_2").value;
                        var email_2 = document.getElementById("email_cadastro_2").value;


                     
                       

                       if ((nome_completo_2 && cpf_contato_2 && telefone_2 && email_2 ) != '') {
                         var soma_2 = 1;
                         document.getElementById("soma_2").value = soma_2;
                          $("#msg_email_2").hide(); 
                          }else {
                                      var soma_2 = 0;
                                     document.getElementById("soma_2").value = soma_2;
                                    
                                    }

                          if (soma_2 == 1) {
                            $("#btn_enviar_cadastro_2").show(); 
                            $("#msg_campo_vazio").hide(); 
                          }
                              if (soma_2 != 1) {
                            $("#btn_enviar_cadastro_2").hide(); 
                            $("#msg_campo_vazio").show(); 
                          }

                       
                        }




     function telefone_contato_2(telefone_2){  /* LETRAS MAIUSCULAS DO NOME*/ 

      var telefone_2 = document.getElementById("telefone_cadastro_2").value;

      telefone_2 = telefone_2.toLowerCase().replace(/(?:^|\s)\S/g, function(capitalize) { return capitalize.toUpperCase(); });

     document.getElementById("telefone_cadastro_2").value = telefone_2;


       //|||||||||||||||||||||||||||||   |||||||||||||||||||   ||||||||||||||||||||||||||  |||||||

     
                          


                          var cpf_contato_2 = document.getElementById("cpf_cadastro_2").value;
                          var nome_completo_2 = document.getElementById("nome_cadastro_2").value;
                          var email_2 = document.getElementById("email_cadastro_2").value;
                                

                           if ((nome_completo_2 && cpf_contato_2 && telefone_2 && email_2 ) != '') {
                               var soma_2 = 1;
                               document.getElementById("soma_2").value = soma_2;   
                               $("#msg_email_2").hide(); 
                                }else {
                                        var soma_2 = 0;
                                       document.getElementById("soma_2").value = soma_2;
                                      }

                                if (soma_2 == 1) {
                                  $("#btn_enviar_cadastro_2").show(); 
                                  $("#msg_campo_vazio").hide(); 
                                  $("#msg_email_2").hide();   

                                }
                                    if (soma_2 != 1) {
                                  $("#btn_enviar_cadastro_2").hide(); 
                                  $("#msg_campo_vazio").show(); 
                                  $("#msg_email_2").show();
                                }
 
    }




      function email_contato_2(email_2){  /* LETRAS MAIUSCULAS DO NOME*/ 

      var email_2 = document.getElementById("email_cadastro_2").value;

      email_2 = email_2.toLowerCase().replace(/(?:^|\s)\S/g, function(capitalize) { return capitalize.toUpperCase(); });

   

      document.getElementById("email_cadastro_2").value = email_2;

      //|||||||||||||||||||||||||||||   |||||||||||||||||||   ||||||||||||||||||||||||||  |||||||

                              


                              var telefone_2 = document.getElementById("telefone_cadastro_2").value;
                              var cpf_contato_2 = document.getElementById("cpf_cadastro_2").value;
                              var nome_completo_2 = document.getElementById("nome_cadastro_2").value;

                                   if ((nome_completo_2 && cpf_contato_2 && telefone_2 && email_2 ) != '') {
                                   var soma_2 = 1;
                                   document.getElementById("soma_2").value = soma_2;

                                   $("#msg_email_2").hide();


                                    }else {
                                            var soma_2 = 0;
                                           document.getElementById("soma_2").value = soma_2;
                          }


                                    if (soma_2 == 1) {
                                      $("#btn_enviar_cadastro_2").show(); 
                                      $("#msg_campo_vazio").hide();

                                    }

                                        if (soma_2 != 1) {
                                      $("#btn_enviar_cadastro_2").hide(); 
                                      $("#msg_campo_vazio").show(); 



                                    }

    }
    
    


     









   //_____________________________________________________________________________





      $(document).ready(function(){  /* MASCARA para os telefones e cpfs*/


        $('#telefone_cadastro').mask ('(00) 0.0000-0000');
       $('#telefone_cadastro_2').mask ('(00) 0.0000-0000');
       
       $('#cpf_cadastro').mask ('000.000.000-00'); 
        $('#cpf_cadastro_2').mask ('000.000.000-00'); 
   

   });




      //_____________________________________________________________________________













    








