



      function cadastrar_1(){

    


			    var descricao_p   = $('#descricao_p').val();
			    var descricao_m   = $('#descricao_m').val();
			    var descricao_g   = $('#descricao_g').val();
			    var descricao_kit = $('#descricao_kit').val();
			    var frete_output  = $('#frete_output').val();
			    

			    var nome_cadastro          = $('#nome_cadastro').val();
			    var endereco_cadastro      = $('#endereco_cadastro').val();
			    var cidade_cadastro        = $('#cidade_cadastro').val();
			    var estado_cadastro        = $('#estado_cadastro').val();
			    var cep_output_2           = $('#cep_output_2').val();
			    var telefone_cadastro      = $('#telefone_cadastro').val();
			    var cpf_cadastro           = $('#cpf_cadastro').val();
			    var email_cadastro         = $('#email_cadastro').val();



			    $.ajax({

			     url:'../back_end/email_vendas_com_frete.php',
			     type:'POST',
			     method:'POST',
			     dataType:'html',
			     cache:false,
			     data: { 
			       descricao_p : descricao_p,
			       descricao_m : descricao_m,
			       descricao_g: descricao_g,
			       descricao_kit: descricao_kit,
			       frete_output: frete_output,
			       nome_cadastro: nome_cadastro,
			       endereco_cadastro: endereco_cadastro,
			       cidade_cadastro: cidade_cadastro,
			       estado_cadastro: estado_cadastro,
			       cep_output_2: cep_output_2,
			       telefone_cadastro: telefone_cadastro,
			       cpf_cadastro: cpf_cadastro,
			       email_cadastro: email_cadastro},

			     success: function(data){

			     	alert('"Com frete" enviado com sucesso');


			      

			     	




			     },beforeSend: function(){


			     },error: function (jqXHR,textStatus,errorThrown){
			     	console.log('Erro');


			        alert('erro no envio');

			     } });

   



      }





      