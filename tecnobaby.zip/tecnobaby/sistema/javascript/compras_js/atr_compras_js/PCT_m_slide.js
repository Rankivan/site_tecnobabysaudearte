   


        window.load = slide_m(1);

        var background_number_m = 1;


        function slide_m(n){

        	var all_backgrouds = 3;

            //Carregamento de imagem via JS

			 document.getElementById("img_slide_m").src = "../../imagens/tec_img/slide_m/"+n+".jpg";

			};//Modificação no link http://localhost/sistemas | https://tecnobabysaudearte.com.br/tecnobaby/


 function anterior_m (){

 	if (background_number_m>1) {

 		background_number_m--;

 		slide_m(background_number_m);

 	}

 	}


function proximo_m (){

 	if (background_number_m<5) {

 		background_number_m++;

 		slide_m(background_number_m);


 	}

 	}