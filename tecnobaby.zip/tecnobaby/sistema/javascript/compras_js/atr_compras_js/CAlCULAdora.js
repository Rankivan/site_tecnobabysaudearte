 
      $("#inserir_prod_no_carr").hide();
      $("#cep_invalido").hide();
      

 function calculador() {


                   


 

         var valor_prod_pct_p = document.getElementById('valor_prod_pct_p').value;  
         var qtd_prod_pct_p   = document.getElementById('qtd_prod_pct_p_output').value;
         var peso_pct_p       = document.getElementById('peso_pct_p').value;
         var dimensao_pct_p   = document.getElementById('dimensao_pct_p').value; 

          valor_prod_pct_p =  parseFloat ( valor_prod_pct_p );
          qtd_prod_pct_p   =  parseFloat ( qtd_prod_pct_p );
          peso_pct_p       =  parseFloat (  peso_pct_p );
          dimensao_pct_p   =  parseFloat ( dimensao_pct_p);

         var valor_prod_pct_m = document.getElementById('valor_prod_pct_m').value;  
         var qtd_prod_pct_m   = document.getElementById('qtd_prod_pct_m_output').value;
         var peso_pct_m       = document.getElementById('peso_pct_m').value;
         var dimensao_pct_m   = document.getElementById('dimensao_pct_m').value; 

          valor_prod_pct_m =  parseFloat ( valor_prod_pct_m );
          qtd_prod_pct_m   =  parseFloat ( qtd_prod_pct_m );
          peso_pct_m       =  parseFloat (  peso_pct_m );
          dimensao_pct_m   =  parseFloat ( dimensao_pct_m);


         var valor_prod_pct_g = document.getElementById('valor_prod_pct_g').value;  
         var qtd_prod_pct_g   = document.getElementById('qtd_prod_pct_g_output').value;
         var peso_pct_g      = document.getElementById('peso_pct_g').value;
         var dimensao_pct_g   = document.getElementById('dimensao_pct_g').value; 

          valor_prod_pct_g  =  parseFloat ( valor_prod_pct_g );
          qtd_prod_pct_g    =  parseFloat ( qtd_prod_pct_g );
          peso_pct_g        =  parseFloat (  peso_pct_g);
          dimensao_pct_g    =  parseFloat ( dimensao_pct_g);
          

         var valor_prod_pct_kit = document.getElementById('valor_prod_pct_kit').value;  
         var qtd_prod_pct_kit    = document.getElementById('qtd_prod_pct_kit_output').value;
         var peso_pct_kit       = document.getElementById('peso_pct_kit').value;
         var dimensao_pct_kit    = document.getElementById('dimensao_pct_kit').value; 

          valor_prod_pct_kit  =  parseFloat ( valor_prod_pct_kit);
          qtd_prod_pct_kit   =  parseFloat ( qtd_prod_pct_kit);
          peso_pct_kit       =  parseFloat (  peso_pct_kit);
          dimensao_pct_kit    =  parseFloat ( dimensao_pct_kit);





         //SAÍDA
          var frete  = document.getElementById('valor_frete_3').value;


         	var soma_valor_produtos = (valor_prod_pct_p) + (valor_prod_pct_m)+ (valor_prod_pct_g)+ (valor_prod_pct_kit);
          var soma_qtd_produtos   = (qtd_prod_pct_p) + (qtd_prod_pct_m)+ (qtd_prod_pct_g)+ (qtd_prod_pct_kit);
          var soma_peso_produtos = (peso_pct_p) + (peso_pct_m)+ (peso_pct_g)+ (peso_pct_kit);
          var dimensao_produtos =  (dimensao_pct_p) + (dimensao_pct_m)+ (dimensao_pct_g)+ (dimensao_pct_kit);


           soma_valor_produtos    =  parseFloat  (soma_valor_produtos);
           soma_qtd_produtos      =  parseFloat  (soma_qtd_produtos);
           soma_peso_produtos     =  parseFloat  (soma_peso_produtos );
           dimensao_produtos      =  parseFloat  (dimensao_produtos);
                      frete       =  parseFloat  (frete);


    





    if (soma_qtd_produtos < 1) {


      $("#text_2").show();

      var frete_total = 0.00 ;
      var text = 'R$';
     //SAÍDA
     document.getElementById('frete_total').value = text+(frete_total.toFixed(2)).replace('.',',');

  
     var total  = 0.00;

     total   =  parseFloat (total);
     //SAÍDA
     document.getElementById('total_final').value = text+(total.toFixed(2)).replace('.',',');

      $("#btn_finalizar_compra").hide();
      $("#inserir_prod_no_carr").show();

   } 


     if (soma_qtd_produtos == 1) {

     $("#text_2").hide();

      $("#btn_finalizar_compra").show();
      $("#inserir_prod_no_carr").hide();

    var frete_total = frete * soma_peso_produtos ;


   }


 
    if (soma_qtd_produtos > 1) {

    $("#text_2").hide();

      $("#btn_finalizar_compra").show();
      $("#inserir_prod_no_carr").hide();

     var frete_total = (frete * (soma_peso_produtos) * (soma_qtd_produtos*0.52))/soma_peso_produtos;

   } 


     if (soma_qtd_produtos > 2) {


     var frete_total = (frete * (soma_peso_produtos) * (soma_qtd_produtos*0.38))/soma_peso_produtos;

   } 

     if (soma_qtd_produtos > 3) {


     var frete_total = (frete * (soma_peso_produtos) * (soma_qtd_produtos*0.35))/soma_peso_produtos;

   } 

  

     var text = 'R$';
     //SAÍDA
     document.getElementById('frete_total').value = text+(frete_total.toFixed(2)).replace('.',',');

     var msg_frete_invalido = frete;

 //________________________________________________________________________________

     //Mensagem frete invalido
     
     document.getElementById('exibir_msg_frete_invalido').value = msg_frete_invalido;
     var cep_invalido_boolean = document.getElementById('cep_invalido_boolean').value;



      if(msg_frete_invalido == 0 && cep_invalido_boolean == 1) {

        $("#cep_invalido").show();


        
      } 

      if(msg_frete_invalido > 0){

        $("#cep_invalido").hide();
        
      }


 //_____________________________SAÍDAS________________________________________________________



  
     var total  = (soma_valor_produtos) + (frete_total);

     total   =  parseFloat (total);
     //SAÍDA
     document.getElementById('total_final').value = text+(total.toFixed(2)).replace('.',',');
     document.getElementById('total_final_3').value = total.toFixed(2);


     var cep =  document.getElementById('cep_destino').value;

      document.getElementById('cep_output').value = cep;
      document.getElementById('cep_output_2').value = cep;


      var frete_output = document.getElementById('frete_total').value;

      document.getElementById('frete_output').value = 'Frete: '+frete_output;







    
   }







              




