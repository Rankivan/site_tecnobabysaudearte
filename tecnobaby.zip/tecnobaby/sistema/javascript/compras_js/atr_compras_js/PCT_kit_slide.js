        


        window.load = slide_kit(1);

        var background_number_kit = 1;


        function slide_kit(n){

        	var all_backgrouds = 3;

            //Carregamento de imagem via JS

			 document.getElementById("img_slide_kit").src = "../../imagens/tec_img/slide_kit/"+n+".jpg";

			}; //Modificação no link http://localhost/sistemas | https://tecnobabysaudearte.com.br/tecnobaby/


 function anterior_kit (){

 	if (background_number_kit>1) {

 		background_number_kit--;

 		slide_kit(background_number_kit);

 	}

 	}


function proximo_kit (){

 	if (background_number_kit<7) {

 		background_number_kit++;

 		slide_kit(background_number_kit);


 	}

 	}