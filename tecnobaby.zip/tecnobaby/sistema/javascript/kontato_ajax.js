




function enviar_formulario(){


  

    var email    = $('#email').val();
    var mensagem = $('#mensagem').val();
    var nome     = $('#nome').val();
    
    


    $.ajax({

     url:'../back_end/email_contato.php',
     type:'POST',
     method:'POST',
     dataType:'html',
     cache:false,
     data: {email : email, mensagem : mensagem, nome: nome},

     success: function(data){


       var msg_contato = 'Mensagem Enviada com sucesso! Agradecemos o contato.'

      document.getElementById('mensagem_contato').value = msg_contato ; 

       
     

     	
       



     },beforeSend: function(){


     },error: function (jqXHR,textStatus,errorThrown){
     	console.log('Erro');


        alert('erro no envio');

     } });



}